package com.idt.toolinventory

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.provider.MediaStore
import android.view.*
import android.widget.*
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.*

private const val GREEN = 0xFF39FF14.toInt()
private const val ORANGE = 0xFFFF7A00.toInt()
private const val BLUE = 0xFF2196F3.toInt()
private const val RED = 0xFFFF3B30.toInt()
private const val BG = 0xFF050505.toInt()
private const val PANEL = 0xFF111518.toInt()
private const val FIELD = 0xFF171D20.toInt()
private const val TEXT = 0xFFF5F5F5.toInt()
private const val MUTED = 0xFFB7B7B7.toInt()

private const val PICK_TOOL_PHOTO = 2101
private const val TAKE_TOOL_PHOTO = 2102
private const val PICK_EMP_PHOTO = 2103
private const val TAKE_EMP_PHOTO = 2104

private data class Tool(
    var number:String, var make:String, var model:String, var type:String,
    var description:String, var serial:String, var value:Double,
    var assignedTo:String="Unassigned", var photo:String="", var employeePhoto:String="",
    var condition:String="Good", var status:String="Available", var notes:String="",
    var employeeSignature:String="", var supervisorSignature:String=""
)

private data class Employee(
    var name:String, var employeeNo:String, var position:String,
    var phone:String="", var email:String="", var photo:String=""
)

class MainActivity : Activity() {
    private lateinit var store:Store
    private var currentTool:Tool?=null
    private var editingTool:Tool?=null
    private var pendingCamera:File?=null
    private var pendingTarget:Int=0
    private var toolPhotoView:ImageView?=null
    private var employeePhotoView:ImageView?=null

    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor=BG
        window.navigationBarColor=BG
        store=Store(this)
        showHome()
    }

    private fun base():LinearLayout=LinearLayout(this).apply{
        orientation=LinearLayout.VERTICAL;setBackgroundColor(BG);setPadding(8,0,8,8)
    }
    private fun scroll():ScrollView=ScrollView(this).apply{setBackgroundColor(BG);isFillViewport=true}
    private fun tv(s:String,size:Float=14f,color:Int=TEXT,bold:Boolean=false)=TextView(this).apply{
        text=s;textSize=size;setTextColor(color);setPadding(10,5,10,5)
        if(bold)setTypeface(typeface,Typeface.BOLD)
    }
    private fun input(hint:String,value:String="")=EditText(this).apply{
        this.hint=hint;setText(value);setTextColor(TEXT);setHintTextColor(MUTED);textSize=14f
        setPadding(12,8,12,8);background=GradientDrawable().apply{setColor(FIELD);setStroke(1,0xFF394348.toInt());cornerRadius=8f}
        layoutParams=LinearLayout.LayoutParams(-1,52).apply{setMargins(4,3,4,5)}
    }
    private fun button(label:String,color:Int=GREEN,action:()->Unit)=Button(this).apply{
        text=label;textSize=14f;setTypeface(typeface,Typeface.BOLD)
        setTextColor(if(color==GREEN)Color.BLACK else Color.WHITE)
        background=GradientDrawable().apply{setColor(color);cornerRadius=10f}
        layoutParams=LinearLayout.LayoutParams(-1,50).apply{setMargins(4,5,4,5)}
        setOnClickListener{action()}
    }
    private fun topBar(title:String,back:()->Unit):LinearLayout=LinearLayout(this).apply{
        orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setBackgroundColor(Color.BLACK)
        addView(Button(this@MainActivity).apply{text="‹";textSize=30f;setTextColor(GREEN);setBackgroundColor(Color.TRANSPARENT);setOnClickListener{back()}},LinearLayout.LayoutParams(58,60))
        addView(tv(title,18f,GREEN,true),LinearLayout.LayoutParams(0,60,1f))
    }
    private fun logo(parent:LinearLayout){
        parent.addView(ImageView(this).apply{setImageResource(R.drawable.idt_logo);scaleType=ImageView.ScaleType.CENTER_INSIDE},LinearLayout.LayoutParams(-1,118))
    }
    private fun card(title:String,value:String,color:Int):LinearLayout=LinearLayout(this).apply{
        orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;background=GradientDrawable().apply{setColor(PANEL);setStroke(2,color);cornerRadius=12f};setPadding(4,8,4,8)
        addView(tv(title,13f,color,true).apply{gravity=Gravity.CENTER})
        addView(tv(value,21f,color,true).apply{gravity=Gravity.CENTER})
    }
    private fun tableHeader(vararg labels:String):LinearLayout=LinearLayout(this).apply{
        setBackgroundColor(Color.BLACK);labels.forEach{addView(tv(it,11f,GREEN,true),LinearLayout.LayoutParams(0,38,1f))}
    }

    private fun showHome(){
        val l=base();logo(l)
        val grid=GridLayout(this).apply{columnCount=2}
        val total=store.tools.size;val assigned=store.tools.count{it.assignedTo!="Unassigned"};val value=store.tools.sumOf{it.value}
        listOf(
            card("🔧  Total Items",total.toString(),GREEN),card("💰  Total Estimated Value","R %.0f".format(value),GREEN),
            card("👤  Assigned",assigned.toString(),GREEN),card("👤  Unassigned",(total-assigned).toString(),ORANGE)
        ).forEachIndexed{i,v->grid.addView(v,GridLayout.LayoutParams().apply{width=0;height=92;columnSpec=GridLayout.spec(i%2,1f);rowSpec=GridLayout.spec(i/2);setMargins(5,5,5,5)})}
        l.addView(grid)
        l.addView(tv("Items by Type",18f,GREEN,true))
        val types=store.tools.groupBy{it.type.ifBlank{"Other Equipment"}}
        if(types.isEmpty())l.addView(tv("No inventory items yet.",14f,MUTED)) else types.forEach{(type,list)->
            val row=LinearLayout(this);row.addView(tv(type,13f,TEXT),LinearLayout.LayoutParams(0,36,1f));row.addView(tv(list.size.toString(),13f,TEXT),LinearLayout.LayoutParams(55,36));row.addView(tv("R %.0f".format(list.sumOf{it.value}),13f,TEXT),LinearLayout.LayoutParams(105,36));l.addView(row)
        }
        l.addView(button("＋  NEW ITEM",GREEN){showNewItem()})
        l.addView(button("⌕  LOOK UP ITEM",GREEN){showLookup()})
        l.addView(button("👥  EMPLOYEES",ORANGE){showEmployees()})
        l.addView(button("▤  REPORTS",ORANGE){showReports()})
        l.addView(button("⚙  SETTINGS",ORANGE){showSettings()})
        l.addView(tv("DESIGN  |  FABRICATION  |  WELDING  |  INSTALLATION\n\nAny size job welcome, big or small we do them all.",14f,ORANGE,true).apply{gravity=Gravity.CENTER;setPadding(8,18,8,22)})
        setContentView(l)
    }

    private fun field(parent:LinearLayout,label:String,value:String=""):EditText{parent.addView(tv(label,12f,GREEN,true));val e=input(label,value);parent.addView(e);return e}

    private fun showNewItem(existing:Tool?=null){
        editingTool=existing
        val l=base();l.addView(topBar(if(existing==null)"New Item" else "Edit Item"){showHome()})
        val sc=scroll();val f=base()
        val number=field(f,"Item Number *",existing?.number?:"IDT-%03d".format(store.tools.size+1))
        val make=field(f,"Make *",existing?.make ?: "")
        val model=field(f,"Model Number",existing?.model?:"")
        val type=field(f,"Type *",existing?.type?:"")
        val desc=field(f,"Description *",existing?.description?:"")
        val serial=field(f,"Serial Number",existing?.serial?:"")
        val value=field(f,"Price Estimate (R)",if(existing==null)"" else existing.value.toString())
        sc.addView(f);l.addView(sc,LinearLayout.LayoutParams(-1,0,1f))
        l.addView(button("Next",ORANGE){
            val t=Tool(number.text.toString(),make.text.toString(),model.text.toString(),type.text.toString(),desc.text.toString(),serial.text.toString(),value.text.toString().toDoubleOrNull()?:0.0,
                existing?.assignedTo?:"Unassigned",existing?.photo?:"",existing?.employeePhoto?:"",existing?.condition?:"Good",existing?.status?:"Available",existing?.notes?:"",existing?.employeeSignature?:"",existing?.supervisorSignature?:"")
            currentTool=t;showAssign(t)
        });setContentView(l)
    }

    private fun showAssign(t:Tool){
        val l=base();l.addView(topBar("Assign to Employee & Photos"){showNewItem(editingTool)})
        val sc=scroll();val f=base();f.addView(tv("Assign to Employee",15f,GREEN,true))
        val names=mutableListOf("Unassigned").apply{addAll(store.employees.map{it.name})};val sp=Spinner(this);sp.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,names);names.indexOf(t.assignedTo).takeIf{it>=0}?.let{sp.setSelection(it)};f.addView(sp)
        f.addView(tv("Employee ID Photo",15f,GREEN,true));employeePhotoView=ImageView(this).apply{setBackgroundColor(Color.WHITE);scaleType=ImageView.ScaleType.CENTER_CROP;visibility=if(t.employeePhoto.isBlank())View.GONE else View.VISIBLE};f.addView(employeePhotoView,LinearLayout.LayoutParams(-1,150))
        f.addView(button("📷  Take Photo",BLUE){pendingTarget=PICK_EMP_PHOTO;takePhoto(false)});f.addView(button("▣  Choose Photo",BLUE){pendingTarget=PICK_EMP_PHOTO;pickPhoto(false)})
        f.addView(tv("Tool Photo",15f,GREEN,true));toolPhotoView=ImageView(this).apply{setBackgroundColor(Color.WHITE);scaleType=ImageView.ScaleType.CENTER_CROP;visibility=if(t.photo.isBlank())View.GONE else View.VISIBLE};f.addView(toolPhotoView,LinearLayout.LayoutParams(-1,180))
        f.addView(button("📷  Take Photo",BLUE){pendingTarget=PICK_TOOL_PHOTO;takePhoto(true)});f.addView(button("▣  Choose Photo",BLUE){pendingTarget=PICK_TOOL_PHOTO;pickPhoto(true)})
        showSavedImage(t.employeePhoto,employeePhotoView);showSavedImage(t.photo,toolPhotoView)
        sc.addView(f);l.addView(sc,LinearLayout.LayoutParams(-1,0,1f));l.addView(button("Next — Signatures",GREEN){t.assignedTo=sp.selectedItem.toString();showSignatures(t)});setContentView(l)
    }

    private fun pickPhoto(tool:Boolean){pendingTarget=if(tool)PICK_TOOL_PHOTO else PICK_EMP_PHOTO;startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="image/*";addCategory(Intent.CATEGORY_OPENABLE);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)},pendingTarget)}

    private fun takePhoto(tool:Boolean){
        pendingTarget=if(tool)TAKE_TOOL_PHOTO else TAKE_EMP_PHOTO
        val file=File(cacheDir,"camera_${System.currentTimeMillis()}.jpg");pendingCamera=file
        val uri=FileProvider.getUriForFile(this,"${packageName}.fileprovider",file)
        startActivityForResult(Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE).apply{putExtra(MediaStore.EXTRA_OUTPUT,uri);addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)},pendingTarget)
    }

    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK)return
        val uri=when(requestCode){PICK_TOOL_PHOTO,PICK_EMP_PHOTO->data?.data;TAKE_TOOL_PHOTO,TAKE_EMP_PHOTO->pendingCamera?.let{Uri.fromFile(it)};else->null}?:return
        try{val saved=copyPhoto(uri);if(requestCode==PICK_TOOL_PHOTO||requestCode==TAKE_TOOL_PHOTO){currentTool?.photo=saved;toolPhotoView?.visibility=View.VISIBLE;showSavedImage(saved,toolPhotoView)}else{currentTool?.employeePhoto=saved;employeePhotoView?.visibility=View.VISIBLE;showSavedImage(saved,employeePhotoView)};Toast.makeText(this,"Photo added successfully",Toast.LENGTH_SHORT).show()}catch(e:Exception){Toast.makeText(this,"Could not save photo: ${e.message}",Toast.LENGTH_LONG).show()}
    }
    private fun copyPhoto(uri:Uri):String{
        val dir=File(filesDir,"photos");dir.mkdirs();val out=File(dir,"photo_${System.currentTimeMillis()}.jpg")
        if(uri.scheme=="file"){File(uri.path!!).copyTo(out,true)}else{contentResolver.openInputStream(uri).use{input->FileOutputStream(out).use{output->input!!.copyTo(output)}}};return out.absolutePath
    }
    private fun showSavedImage(path:String,iv:ImageView?){if(iv==null||path.isBlank())return;val f=File(path);if(f.exists()){iv.setImageBitmap(BitmapFactory.decodeFile(path));iv.visibility=View.VISIBLE}}

    private fun showSignatures(t:Tool){
        val l=base();l.addView(topBar("Signatures"){showAssign(t)});val sc=scroll();val f=base()
        f.addView(tv("Employee Signature",15f,GREEN,true));val es=SignatureView(this);f.addView(es,LinearLayout.LayoutParams(-1,160));f.addView(button("Clear",ORANGE){es.clear()})
        f.addView(tv("Supervisor Signature",15f,GREEN,true));val ss=SignatureView(this);f.addView(ss,LinearLayout.LayoutParams(-1,160));f.addView(button("Clear",ORANGE){ss.clear()})
        val notes=field(f,"Notes",t.notes.ifBlank{"Good condition. Assigned for site use."});sc.addView(f);l.addView(sc,LinearLayout.LayoutParams(-1,0,1f));l.addView(button("Save Item",GREEN){
            t.notes=notes.text.toString();t.employeeSignature=saveSignature(es,"employee");t.supervisorSignature=saveSignature(ss,"supervisor")
            val i=store.tools.indexOfFirst{it.number==t.number};if(i>=0)store.tools[i]=t else store.tools.add(t);store.save();showItemDetails(t)
        });setContentView(l)
    }
    private fun saveSignature(v:SignatureView,name:String):String{if(v.isBlank())return "";val dir=File(filesDir,"signatures");dir.mkdirs();val f=File(dir,"${name}_${System.currentTimeMillis()}.png");FileOutputStream(f).use{v.bitmap().compress(Bitmap.CompressFormat.PNG,100,it)};return f.absolutePath}

    private fun showLookup(){
        val l=base();l.addView(topBar("Look Up Item"){showHome()});val search=input("Search item number, make, model...");l.addView(search);val list=base();val sc=scroll();sc.addView(list);l.addView(sc,LinearLayout.LayoutParams(-1,0,1f))
        fun refresh(){list.removeAllViews();val q=search.text.toString().lowercase();store.tools.filter{q.isBlank()||"${it.number} ${it.make} ${it.model} ${it.serial}".lowercase().contains(q)}.forEach{t->list.addView(itemRow(t))}}
        search.addTextChangedListener(SimpleWatcher{refresh()});refresh();setContentView(l)
    }
    private fun itemRow(t:Tool)=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(6,6,6,6);background=GradientDrawable().apply{setColor(PANEL);setStroke(1,GREEN);cornerRadius=10f};val iv=ImageView(this@MainActivity).apply{scaleType=ImageView.ScaleType.CENTER_CROP};showSavedImage(t.photo,iv);addView(iv,LinearLayout.LayoutParams(78,78));addView(tv("${t.number}\n${t.make} ${t.model}\nS/N: ${t.serial}\n${t.assignedTo}",13f,TEXT,true),LinearLayout.LayoutParams(0,86,1f));setOnClickListener{showItemDetails(t)}}

    private fun showItemDetails(t:Tool){
        val l=base();l.addView(topBar("Item Details"){showLookup()});val sc=scroll();val f=base();val iv=ImageView(this).apply{scaleType=ImageView.ScaleType.CENTER_CROP};showSavedImage(t.photo,iv);f.addView(iv,LinearLayout.LayoutParams(-1,210));f.addView(tv("${t.number}\n${t.make} ${t.model}\nType: ${t.type}\nDescription: ${t.description}\nSerial Number: ${t.serial}\nEstimated Value: R %.2f\nAssigned To: ${t.assignedTo}\nCondition: ${t.condition}\nStatus: ${t.status}\nNotes: ${t.notes}",14f))
        f.addView(button("Edit Item",GREEN){showNewItem(t)});f.addView(button("Generate Individual PDF",BLUE){sharePdf(PdfMaker.item(this,t,store))});sc.addView(f);l.addView(sc,LinearLayout.LayoutParams(-1,0,1f));setContentView(l)
    }

    private fun showEmployees(){val l=base();l.addView(topBar("Employees"){showHome()});l.addView(button("＋ Add Employee",GREEN){showEmployeeForm(null)});val sc=scroll();val f=base();store.employees.forEach{e->val count=store.tools.count{it.assignedTo==e.name};f.addView(button("${e.name}\n${e.employeeNo} • ${e.position}\n$count Items",GREEN){showEmployeeDetails(e)})};sc.addView(f);l.addView(sc,LinearLayout.LayoutParams(-1,0,1f));setContentView(l)}
    private fun showEmployeeForm(existing:Employee?){val l=base();l.addView(topBar(if(existing==null)"Add Employee" else "Edit Employee"){showEmployees()});val sc=scroll();val f=base();val n=field(f,"Full Name",existing?.name ?: "");val no=field(f,"Employee Number",existing?.employeeNo?:"");val p=field(f,"Position",existing?.position?:"Welder / Fabricator");val ph=field(f,"Contact Number",existing?.phone?:"");val em=field(f,"Email",existing?.email?:"");sc.addView(f);l.addView(sc,LinearLayout.LayoutParams(-1,0,1f));l.addView(button("Save Employee",GREEN){val e=Employee(n.text.toString(),no.text.toString(),p.text.toString(),ph.text.toString(),em.text.toString(),existing?.photo?:"");val i=store.employees.indexOfFirst{it.employeeNo==e.employeeNo};if(i>=0)store.employees[i]=e else store.employees.add(e);store.save();showEmployees()});setContentView(l)}
    private fun showEmployeeDetails(e:Employee){val l=base();l.addView(topBar("Employee Details"){showEmployees()});val sc=scroll();val f=base();f.addView(tv("${e.name}\n${e.employeeNo}\n${e.position}\n${e.phone}\n${e.email}",17f));f.addView(tv("Assigned Tools",16f,GREEN,true));store.tools.filter{it.assignedTo==e.name}.forEach{f.addView(tv("${it.number} • ${it.make} ${it.model} • R %.2f".format(it.value),14f))};f.addView(button("Generate Employee Tool List PDF",BLUE){sharePdf(PdfMaker.employee(this,e,store))});f.addView(button("Edit Employee",ORANGE){showEmployeeForm(e)});sc.addView(f);l.addView(sc,LinearLayout.LayoutParams(-1,0,1f));setContentView(l)}

    private fun showReports(){val l=base();l.addView(topBar("Reports"){showHome()});val sc=scroll();val f=base();f.addView(button("📄  Individual Item Report",GREEN){if(store.tools.isNotEmpty())sharePdf(PdfMaker.item(this,store.tools.first(),store))});f.addView(button("📄  Employee Tool List Report",ORANGE){if(store.employees.isNotEmpty())sharePdf(PdfMaker.employee(this,store.employees.first(),store))});f.addView(button("📄  All Items Report",BLUE){sharePdf(PdfMaker.all(this,store))});sc.addView(f);l.addView(sc,LinearLayout.LayoutParams(-1,0,1f));setContentView(l)}
    private fun showSettings(){val l=base();l.addView(topBar("Settings"){showHome()});val sc=scroll();val f=base();f.addView(tv("I.D.T. STEELWORKS AND ENGINEERING\nWelding • Fabrication • Installation\nWestern Cape\niwardio@idtsteelwork.co.za",16f));f.addView(button("Clear all local inventory",RED){AlertDialog.Builder(this).setTitle("Clear inventory?").setMessage("Delete all local records?").setNegativeButton("Cancel",null).setPositiveButton("Clear"){_,_->store.tools.clear();store.employees.clear();store.save();showHome()}.show()});sc.addView(f);l.addView(sc,LinearLayout.LayoutParams(-1,0,1f));setContentView(l)}

    private fun sharePdf(file:File){val uri=FileProvider.getUriForFile(this,"${packageName}.fileprovider",file);startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="application/pdf";putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)},"Share IDT PDF"))}
}

private class SimpleWatcher(val fn:()->Unit):android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){fn()};override fun afterTextChanged(s:android.text.Editable?){}}

class SignatureView(ctx:Context):View(ctx){private val path=Path();private val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.BLACK;style=Paint.Style.STROKE;strokeWidth=5f;strokeCap=Paint.Cap.ROUND};private var down=false;init{setBackgroundColor(Color.WHITE)};override fun onDraw(c:Canvas){c.drawColor(Color.WHITE);c.drawPath(path,paint)};override fun onTouchEvent(e:android.view.MotionEvent):Boolean{when(e.action){MotionEvent.ACTION_DOWN->path.moveTo(e.x,e.y);MotionEvent.ACTION_MOVE->path.lineTo(e.x,e.y);MotionEvent.ACTION_UP->invalidate()};invalidate();return true};fun clear(){path.reset();invalidate()};fun isBlank()=path.isEmpty;fun bitmap():Bitmap{val b=Bitmap.createBitmap(width.coerceAtLeast(1),height.coerceAtLeast(1),Bitmap.Config.ARGB_8888);Canvas(b).also{it.drawColor(Color.WHITE);it.drawPath(path,paint)};return b}}

class Store(private val ctx:Context){val tools=mutableListOf<Tool>();val employees=mutableListOf<Employee>();private val p=ctx.getSharedPreferences("idt_inventory",Context.MODE_PRIVATE)
    init{load();if(tools.isEmpty()&&employees.isEmpty())seed()}
    private fun seed(){employees.addAll(listOf(Employee("Iwardio Du Toit","IDT-001","Manager"),Employee("Johan Smith","IDT-003","Welder / Fabricator"),Employee("Pieter Jacobs","IDT-004","Installer"),Employee("Mark Daniels","IDT-005","General Worker")));tools.addAll(listOf(Tool("IDT-001","Makita","DHR243Z","Rotary Hammer","18V Cordless Rotary Hammer Drill with 3 modes","A1234567",3699.0,"Johan Smith"),Tool("IDT-002","DeWalt","DWE7492","Table Saw","Heavy duty table saw","B7654321",8500.0,"Mark Daniels"),Tool("IDT-003","Bosch","GWS 2200","Angle Grinder","Professional angle grinder","C9876543",2450.0,"Pieter Jacobs"),Tool("IDT-004","Lincoln","PowerMIG 220","Welding Machine","Portable welding machine","L1122334",9500.0,"Iwardio Du Toit"),Tool("IDT-005","Makita","DTD152","Impact Driver","18V impact driver","M2233445","Johan Smith".let{2150.0})));save()}
    fun save(){val ta=JSONArray();tools.forEach{ta.put(JSONObject().apply{put("number",it.number);put("make",it.make);put("model",it.model);put("type",it.type);put("description",it.description);put("serial",it.serial);put("value",it.value);put("assignedTo",it.assignedTo);put("photo",it.photo);put("employeePhoto",it.employeePhoto);put("condition",it.condition);put("status",it.status);put("notes",it.notes);put("employeeSignature",it.employeeSignature);put("supervisorSignature",it.supervisorSignature)})};val ea=JSONArray();employees.forEach{ea.put(JSONObject().apply{put("name",it.name);put("employeeNo",it.employeeNo);put("position",it.position);put("phone",it.phone);put("email",it.email);put("photo",it.photo)})};p.edit().putString("tools",ta.toString()).putString("employees",ea.toString()).apply()}
    private fun load(){try{JSONArray(p.getString("tools","[]")).also{for(i in 0 until it.length()){val o=it.getJSONObject(i);tools.add(Tool(o.optString("number"),o.optString("make"),o.optString("model"),o.optString("type"),o.optString("description"),o.optString("serial"),o.optDouble("value"),o.optString("assignedTo","Unassigned"),o.optString("photo"),o.optString("employeePhoto"),o.optString("condition","Good"),o.optString("status","Available"),o.optString("notes"),o.optString("employeeSignature"),o.optString("supervisorSignature")))}};JSONArray(p.getString("employees","[]")).also{for(i in 0 until it.length()){val o=it.getJSONObject(i);employees.add(Employee(o.optString("name"),o.optString("employeeNo"),o.optString("position"),o.optString("phone"),o.optString("email"),o.optString("photo")))}}}catch(_:Exception){tools.clear();employees.clear()}}
}

object PdfMaker{
    private const val W=595;private const val H=842
    private fun header(c:Canvas,p:Paint,title:String){p.color=Color.BLACK;c.drawRect(0f,0f,W.toFloat(),62f,p);p.color=GREEN;p.textSize=17f;p.typeface=Typeface.DEFAULT_BOLD;c.drawText("I.D.T. STEELWORKS AND ENGINEERING",18f,24f,p);p.color=Color.WHITE;p.textSize=9f;p.typeface=Typeface.DEFAULT;c.drawText("Welding | Fabrication | Installation",18f,39f,p);p.color=ORANGE;p.textSize=12f;p.typeface=Typeface.DEFAULT_BOLD;c.drawText(title,18f,55f,p)}
    private fun img(c:Canvas,path:String,left:Float,top:Float,right:Float,bottom:Float){if(path.isBlank())return;val b=BitmapFactory.decodeFile(path)?:return;c.drawBitmap(b,null,RectF(left,top,right,bottom),Paint(Paint.ANTI_ALIAS_FLAG))}
    fun item(ctx:Context,t:Tool,s:Store):File{val d=android.graphics.pdf.PdfDocument();val page=d.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(W,H,1).create());val c=page.canvas;p(c).also{header(c,it,"TOOL INVENTORY REPORT - INDIVIDUAL ITEM")};var y=90f;val p=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.BLACK;textSize=11f};val lines=listOf("Item Number: ${t.number}","Make: ${t.make}","Model: ${t.model}","Type: ${t.type}","Description: ${t.description}","Serial Number: ${t.serial}","Estimated Value: R %.2f".format(t.value),"Assigned To: ${t.assignedTo}","Condition: ${t.condition}","Status: ${t.status}","Notes: ${t.notes}");lines.forEach{c.drawText(it.take(72),18f,y,p);y+=23};img(c,t.photo,365f,92f,570f,280f);p.textSize=10f;c.drawText("Employee Signature",25f,710f,p);c.drawText("Supervisor Signature",325f,710f,p);img(c,t.employeeSignature,20f,720f,275f,790f);img(c,t.supervisorSignature,320f,720f,575f,790f);d.finishPage(page);return write(ctx,d,"IDT-Individual-${t.number}.pdf")}
    fun employee(ctx:Context,e:Employee,s:Store):File{val d=android.graphics.pdf.PdfDocument();val page=d.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(W,H,1).create());val c=page.canvas;val p=p(c);header(c,p,"EMPLOYEE TOOL ASSIGNMENT REPORT");p.color=Color.BLACK;p.textSize=12f;c.drawText("${e.name} • ${e.employeeNo} • ${e.position}",18f,86f,p);var y=120f;s.tools.filter{it.assignedTo==e.name}.forEachIndexed{i,t->{c.drawText("${i+1}. ${t.number}   ${t.make} ${t.model}   S/N ${t.serial}   R %.2f".format(t.value),18f,y,p);img(c,t.photo,500f,y-15,570f,y+35);y+=45}};d.finishPage(page);return write(ctx,d,"IDT-Employee-${e.employeeNo}.pdf")}
    fun all(ctx:Context,s:Store):File{val d=android.graphics.pdf.PdfDocument();val page=d.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(W,H,1).create());val c=page.canvas;val p=p(c);header(c,p,"COMPLETE TOOL INVENTORY REPORT");p.color=Color.BLACK;p.textSize=8f;c.drawText("# Item    Make     Model      Type          Serial       Assigned        Value",15f,84f,p);var y=103f;s.tools.take(25).forEachIndexed{i,t->{c.drawText("${i+1} ${t.number} ${t.make.take(8)} ${t.model.take(9)} ${t.type.take(11)} ${t.serial.take(9)} ${t.assignedTo.take(12)} R%.0f".format(t.value),15f,y,p);y+=26}};p.textSize=13f;p.typeface=Typeface.DEFAULT_BOLD;c.drawText("Total Estimated Value: R %.2f".format(s.tools.sumOf{it.value}),350f,800f,p);d.finishPage(page);return write(ctx,d,"IDT-Complete-Inventory.pdf")}
    private fun p(c:Canvas)=Paint(Paint.ANTI_ALIAS_FLAG)
    private fun write(ctx:Context,d:android.graphics.pdf.PdfDocument,name:String):File{val dir=File(ctx.cacheDir,"reports");dir.mkdirs();val f=File(dir,name);FileOutputStream(f).use{d.writeTo(it)};d.close();return f}
}
