# IDT Tool Inventory APP - Firebase Live Sync V3

This package contains the complete Android project for I.D.T. Steelworks & Engineering.

Firebase project: `idt-tool-inventory`
Android package: `com.idt.toolinventory`

The GitHub Actions workflow is designed to build the latest `IDT-Tool-Inventory-APP-FIREBASE-LIVE-SYNC-V*.zip` source archive in the repository, so uploading a new source ZIP does not accidentally build an older Android project left in the repository root.
