# IDT Tool Inventory APP

I.D.T. STEELWORKS AND ENGINEERING tool and equipment inventory app.

## Included
- Dashboard matching the IDT black / neon-green / orange design
- New item workflow
- Employee assignment
- Tool and employee photo capture/selection
- Offline local storage
- Employee list
- Item lookup
- Signature capture
- Individual item, employee assignment and complete inventory PDF reports
- PDF sharing
- GitHub Actions Android APK build

Company: I.D.T. STEELWORKS AND ENGINEERING
Email: iwardio@idtsteelwork.co.za
Region: Western Cape
