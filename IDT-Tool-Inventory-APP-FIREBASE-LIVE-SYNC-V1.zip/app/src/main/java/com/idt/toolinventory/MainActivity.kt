package com.idt.toolinventory

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.provider.MediaStore
import android.view.*
import android.widget.*
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.FileInputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import java.text.SimpleDateFormat
import java.util.*
import java.util.Locale
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions

private const val GREEN = 0xFF39FF14.toInt()
private const val ORANGE = 0xFFFF7A00.toInt()
private const val BLUE = 0xFF2196F3.toInt()
private const val RED = 0xFFFF3B30.toInt()
private const val BG = 0xFF050505.toInt()
private const val PANEL = 0xFF111518.toInt()
private const val FIELD = 0xFF171D20.toInt()
private const val TEXT = 0xFFF5F5F5.toInt()
private const val MUTED = 0xFFB7B7B7.toInt()

private const val PICK_TOOL_PHOTO = 2101
private const val TAKE_TOOL_PHOTO = 2102
private const val PICK_EMP_PHOTO = 2103
private const val TAKE_EMP_PHOTO = 2104
private const val BACKUP_CREATE = 3101
private const val BACKUP_OPEN = 3102
private const val SYNC_OPEN = 3201

data class Tool(
    var number:String, var make:String, var model:String, var type:String,
    var description:String, var serial:String, var value:Double,
    var assignedTo:String="Unassigned", var photo:String="", var employeePhoto:String="",
    var condition:String="Good", var status:String="Available", var notes:String="",
    var employeeSignature:String="", var supervisorSignature:String=""
)

data class Employee(
    var name:String, var employeeNo:String, var position:String,
    var phone:String="", var email:String="", var photo:String=""
)

class MainActivity : Activity() {
    private lateinit var store:Store
    private var currentTool:Tool?=null
    private var editingTool:Tool?=null
    private var pendingCamera:File?=null
    private var pendingTarget:Int=0
    private var toolPhotoView:ImageView?=null
    private var employeePhotoView:ImageView?=null
    private var employeeFormPhotoView:ImageView?=null
    private var employeeFormPhotoPath:String=""
    private lateinit var cloud:FirebaseCloudSync

    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor=BG
        window.navigationBarColor=BG
        store=Store(this)
        cloud=FirebaseCloudSync(this, store)
        store.onSaved={ cloud.pushLocalSnapshot() }
        cloud.start()
        showHome()
    }

    private fun base():LinearLayout=LinearLayout(this).apply{
        orientation=LinearLayout.VERTICAL;setBackgroundColor(BG);setPadding(8,0,8,0)
    }
    private fun protectBottom(v:LinearLayout){
        v.setOnApplyWindowInsetsListener { view, insets ->
            val bottom = if(Build.VERSION.SDK_INT >= 30)
                insets.getInsets(WindowInsets.Type.navigationBars()).bottom
            else
                insets.systemWindowInsetBottom
            val extra = (16 * resources.displayMetrics.density).toInt()
            view.setPadding(view.paddingLeft,view.paddingTop,view.paddingRight,bottom + extra)
            insets
        }
        v.requestApplyInsets()
    }
    private fun setScreen(v:LinearLayout){
        val shell=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setBackgroundColor(BG)}
        val nav=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL;gravity=Gravity.TOP;setBackgroundColor(PANEL);setPadding(4,10,4,10)
        }
        nav.addView(tv("IDT",18f,GREEN,true).apply{gravity=Gravity.CENTER;setPadding(0,4,0,14)})
        fun navBtn(icon:String,label:String,action:()->Unit)=Button(this).apply{
            text="$icon  $label";textSize=11f;setTextColor(GREEN);setBackgroundColor(Color.TRANSPARENT);gravity=Gravity.CENTER_VERTICAL;setPadding(6,0,4,0);includeFontPadding=false;minHeight=0;minimumHeight=0
            layoutParams=LinearLayout.LayoutParams(-1,58).apply{setMargins(2,3,2,3)};setOnClickListener{action()}
        }
        nav.addView(navBtn("⌂","HOME"){showHome()})
        nav.addView(navBtn("+","NEW ITEM"){showNewItem()})
        nav.addView(navBtn("⌕","LOOK UP"){showLookup()})
        nav.addView(navBtn("👥","EMPLOYEES"){showEmployees()})
        nav.addView(navBtn("▤","REPORTS"){showReports()})
        nav.addView(navBtn("⇄","SYNC"){showSync()})
        nav.addView(navBtn("⚙","SETTINGS"){showSettings()})
        shell.addView(nav,LinearLayout.LayoutParams(112,-1))
        shell.addView(v,LinearLayout.LayoutParams(0,-1,1f))
        shell.systemUiVisibility = 0
        setContentView(shell)
    }
    private fun scroll():ScrollView=ScrollView(this).apply{setBackgroundColor(BG);isFillViewport=true}
    private fun tv(s:String,size:Float=14f,color:Int=TEXT,bold:Boolean=false)=TextView(this).apply{
        text=s;textSize=size;setTextColor(color);setPadding(10,5,10,5)
        if(bold)setTypeface(typeface,Typeface.BOLD)
    }
    private fun input(hint:String,value:String="")=EditText(this).apply{
        this.hint=hint;setText(value);setTextColor(TEXT);setHintTextColor(MUTED);textSize=14f
        setPadding(12,8,12,8);background=GradientDrawable().apply{setColor(FIELD);setStroke(1,0xFF394348.toInt());cornerRadius=8f}
        layoutParams=LinearLayout.LayoutParams(-1,52).apply{setMargins(4,3,4,5)}
    }
    private fun button(label:String,color:Int=GREEN,action:()->Unit)=Button(this).apply{
        text=label;textSize=14f;setTypeface(typeface,Typeface.BOLD)
        setTextColor(if(color==GREEN)Color.BLACK else Color.WHITE)
        gravity=Gravity.CENTER
        includeFontPadding=false
        minHeight=0;minimumHeight=0
        setPadding(12,0,12,0)
        background=GradientDrawable().apply{setColor(color);cornerRadius=10f}
        layoutParams=LinearLayout.LayoutParams(-1,54).apply{setMargins(4,5,4,5)}
        setOnClickListener{action()}
    }
    private fun topBar(title:String,back:()->Unit):LinearLayout=LinearLayout(this).apply{
        orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setBackgroundColor(Color.BLACK)
        addView(Button(this@MainActivity).apply{text="‹";textSize=30f;setTextColor(GREEN);setBackgroundColor(Color.TRANSPARENT);setOnClickListener{back()}},LinearLayout.LayoutParams(58,60))
        addView(tv(title,18f,GREEN,true),LinearLayout.LayoutParams(0,60,1f))
    }
    private fun logo(parent:LinearLayout){
        parent.addView(ImageView(this).apply{setImageResource(R.drawable.idt_logo);scaleType=ImageView.ScaleType.CENTER_INSIDE},LinearLayout.LayoutParams(-1,118))
    }
    private fun card(title:String,value:String,color:Int):LinearLayout=LinearLayout(this).apply{
        orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;background=GradientDrawable().apply{setColor(PANEL);setStroke(2,color);cornerRadius=12f};setPadding(4,8,4,8)
        addView(tv(title,13f,color,true).apply{gravity=Gravity.CENTER})
        addView(tv(value,21f,color,true).apply{gravity=Gravity.CENTER})
    }
    private fun tableHeader(vararg labels:String):LinearLayout=LinearLayout(this).apply{
        setBackgroundColor(Color.BLACK);labels.forEach{addView(tv(it,11f,GREEN,true),LinearLayout.LayoutParams(0,38,1f))}
    }

    private fun showHome(){
        val l=base();l.addView(topBar("IDT TOOL INVENTORY"){showHome()})
        val sc=scroll();val content=base();logo(content)
        val grid=GridLayout(this).apply{columnCount=2}
        val total=store.tools.size;val assigned=store.tools.count{it.assignedTo!="Unassigned"};val value=store.tools.sumOf{it.value}
        listOf(
            card("🔧  Total Items",total.toString(),GREEN),card("💰  Total Estimated Value","R %.0f".format(value),GREEN),
            card("👤  Assigned",assigned.toString(),GREEN),card("👤  Unassigned",(total-assigned).toString(),ORANGE)
        ).forEachIndexed{i,v->grid.addView(v,GridLayout.LayoutParams().apply{width=0;height=92;columnSpec=GridLayout.spec(i%2,1f);rowSpec=GridLayout.spec(i/2);setMargins(5,5,5,5)})}
        content.addView(grid)
        content.addView(tv("Items by Type",18f,GREEN,true))
        val types=store.tools.groupBy{it.type.ifBlank{"Other Equipment"}}
        if(types.isEmpty())content.addView(tv("No inventory items yet.",14f,MUTED)) else types.forEach{(type,list)->
            val row=LinearLayout(this);row.addView(tv(type,13f,TEXT),LinearLayout.LayoutParams(0,36,1f));row.addView(tv(list.size.toString(),13f,TEXT),LinearLayout.LayoutParams(55,36));row.addView(tv("R %.0f".format(list.sumOf{it.value}),13f,TEXT),LinearLayout.LayoutParams(105,36));content.addView(row)
        }
        content.addView(button("＋  NEW ITEM",GREEN){showNewItem()})
        content.addView(button("⌕  LOOK UP ITEM",GREEN){showLookup()})
        content.addView(button("👥  EMPLOYEES",ORANGE){showEmployees()})
        content.addView(button("▤  REPORTS",ORANGE){showReports()})
        content.addView(button("⚙  SETTINGS",ORANGE){showSettings()})
        content.addView(tv("DESIGN  |  FABRICATION  |  WELDING  |  INSTALLATION\n\nAny size job welcome, big or small we do them all.",14f,ORANGE,true).apply{gravity=Gravity.CENTER;setPadding(8,18,8,30)})
        sc.addView(content);l.addView(sc,LinearLayout.LayoutParams(-1,0,1f));setScreen(l)
    }

    private fun field(parent:LinearLayout,label:String,value:String=""):EditText{parent.addView(tv(label,12f,GREEN,true));val e=input(label,value);parent.addView(e);return e}

    private fun showNewItem(existing:Tool?=null){
        editingTool=existing
        val l=base();l.addView(topBar(if(existing==null)"New Item" else "Edit Item"){showHome()})
        val sc=scroll();val f=base()
        val number=field(f,"Item Number *",existing?.number?:"IDT-%03d".format(store.tools.size+1))
        val make=field(f,"Make *",existing?.make ?: "")
        val model=field(f,"Model Number",existing?.model?:"")
        val type=field(f,"Type *",existing?.type?:"")
        val desc=field(f,"Description *",existing?.description?:"")
        val serial=field(f,"Serial Number",existing?.serial?:"")
        val value=field(f,"Price Estimate (R)",if(existing==null)"" else existing.value.toString())
        fun makeTool():Tool=Tool(
            number.text.toString().trim(),make.text.toString().trim(),model.text.toString().trim(),
            type.text.toString().trim(),desc.text.toString().trim(),serial.text.toString().trim(),
            parseMoney(value.text.toString()),
            existing?.assignedTo?:"Unassigned",existing?.photo?:"",existing?.employeePhoto?:"",
            existing?.condition?:"Good",existing?.status?:"Available",existing?.notes?:"",
            existing?.employeeSignature?:"",existing?.supervisorSignature?:""
        )
        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        actions.addView(button("SAVE",BLUE){
            val t=makeTool()
            val i=store.tools.indexOfFirst{it.number==t.number}
            if(i>=0)store.tools[i]=t else store.tools.add(t)
            store.save()
            Toast.makeText(this@MainActivity,"Item saved successfully.",Toast.LENGTH_SHORT).show()
            showHome()
        },LinearLayout.LayoutParams(0,54,1f))
        actions.addView(button("SAVE & ADD ANOTHER",ORANGE){
            val t=makeTool()
            val i=store.tools.indexOfFirst{it.number==t.number}
            if(i>=0)store.tools[i]=t else store.tools.add(t)
            store.save()
            Toast.makeText(this@MainActivity,"Item saved. Add the next item.",Toast.LENGTH_SHORT).show()
            showNewItem(null)
        },LinearLayout.LayoutParams(0,54,1f))
        f.addView(button("NEXT — ASSIGN EMPLOYEE & PHOTO",GREEN){
            val t=makeTool()
            currentTool=t;showAssign(t)
        })
        f.addView(actions)
        sc.addView(f);l.addView(sc,LinearLayout.LayoutParams(-1,0,1f))
        setScreen(l)
    }

    private fun parseMoney(raw:String):Double{
        val cleaned=raw.replace("R","",ignoreCase=true).replace(",","").replace(" ","").trim()
        return cleaned.toDoubleOrNull() ?: 0.0
    }

    private fun showAssign(t:Tool){
        val l=base();l.addView(topBar("Assign to Employee & Tool Photo"){showNewItem(editingTool)})
        val sc=scroll();val f=base();f.addView(tv("Assign to Employee",15f,GREEN,true))
        val names=mutableListOf("Unassigned").apply{addAll(store.employees.map{it.name})}
        val sp=Spinner(this).apply{
            adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,names)
            names.indexOf(t.assignedTo).takeIf{it>=0}?.let{setSelection(it)}
        }
        f.addView(sp)
        val employeeCard=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(8,8,8,8);background=GradientDrawable().apply{setColor(PANEL);setStroke(1,0xFF394348.toInt());cornerRadius=10f}}
        employeePhotoView=ImageView(this).apply{setBackgroundColor(FIELD);scaleType=ImageView.ScaleType.CENTER_CROP}
        val employeeText=tv("No employee selected",14f,TEXT,true)
        employeeCard.addView(employeePhotoView,LinearLayout.LayoutParams(92,92).apply{setMargins(0,0,10,0)})
        employeeCard.addView(employeeText,LinearLayout.LayoutParams(0,92,1f));f.addView(employeeCard)
        fun refreshEmployee(){
            val selected=store.employees.firstOrNull{it.name==sp.selectedItem?.toString()}
            if(selected==null){employeeText.text="No employee selected";employeePhotoView?.setImageDrawable(null)}
            else{employeeText.text="${selected.name}\n${selected.employeeNo}\n${selected.position}";employeePhotoView?.setImageDrawable(null);showSavedImage(selected.photo,employeePhotoView)}
        }
        sp.onItemSelectedListener=object:android.widget.AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent:android.widget.AdapterView<*>?,view:View?,position:Int,id:Long){refreshEmployee()}
            override fun onNothingSelected(parent:android.widget.AdapterView<*>?){refreshEmployee()}
        }
        refreshEmployee()
        f.addView(tv("Tool Photo",15f,GREEN,true));toolPhotoView=ImageView(this).apply{setBackgroundColor(Color.WHITE);scaleType=ImageView.ScaleType.CENTER_CROP;visibility=if(t.photo.isBlank())View.GONE else View.VISIBLE};f.addView(toolPhotoView,LinearLayout.LayoutParams(-1,180))
        f.addView(button("📷  Take Tool Photo",BLUE){takePhoto(true)});f.addView(button("▣  Choose Tool Photo",BLUE){pickPhoto(true)})
        showSavedImage(t.photo,toolPhotoView)
        sc.addView(f);l.addView(sc,LinearLayout.LayoutParams(-1,0,1f));l.addView(button("Next — Signatures",GREEN){
            t.assignedTo=sp.selectedItem.toString()
            t.employeePhoto=store.employees.firstOrNull{it.name==t.assignedTo}?.photo ?: ""
            showSignatures(t)
        });setScreen(l)
    }

    private fun pickPhoto(tool:Boolean){
        pendingTarget=if(tool)PICK_TOOL_PHOTO else PICK_EMP_PHOTO
        val intent=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{
            type="image/*"
            addCategory(Intent.CATEGORY_OPENABLE)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        try{startActivityForResult(intent,pendingTarget)}
        catch(_:Exception){
            startActivityForResult(Intent(Intent.ACTION_PICK).apply{type="image/*"},pendingTarget)
        }
    }

    private fun takePhoto(tool:Boolean){
        pendingTarget=if(tool)TAKE_TOOL_PHOTO else TAKE_EMP_PHOTO
        val file=File(cacheDir,"camera_${System.currentTimeMillis()}.jpg");pendingCamera=file
        val uri=FileProvider.getUriForFile(this,"${packageName}.fileprovider",file)
        startActivityForResult(Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE).apply{putExtra(MediaStore.EXTRA_OUTPUT,uri);addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)},pendingTarget)
    }

    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode,resultCode,data)
        if(resultCode!=RESULT_OK)return
        val uri=when(requestCode){
            PICK_TOOL_PHOTO,PICK_EMP_PHOTO->data?.data
            TAKE_TOOL_PHOTO,TAKE_EMP_PHOTO->pendingCamera?.let{Uri.fromFile(it)}
            else->null
        }?:return
        try{
            if(data?.data!=null && uri.scheme=="content"){
                try{contentResolver.takePersistableUriPermission(uri,data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION))}catch(_:Exception){}
            }
            val saved=copyPhoto(uri)
            if(requestCode==PICK_TOOL_PHOTO||requestCode==TAKE_TOOL_PHOTO){
                currentTool?.photo=saved
                toolPhotoView?.visibility=View.VISIBLE
                showSavedImage(saved,toolPhotoView)
            }else{
                employeeFormPhotoPath=saved
                employeeFormPhotoView?.visibility=View.VISIBLE
                showSavedImage(saved,employeeFormPhotoView)
            }
            pendingCamera=null
            Toast.makeText(this,"Photo added successfully",Toast.LENGTH_SHORT).show()
        }catch(e:Exception){
            Toast.makeText(this,"Could not save photo: ${e.message}",Toast.LENGTH_LONG).show()
        }
    }
    private fun copyPhoto(uri:Uri):String{
        val dir=File(filesDir,"photos");dir.mkdirs()
        val out=File(dir,"photo_${System.currentTimeMillis()}.jpg")
        val bitmap=if(uri.scheme=="file"){
            BitmapFactory.decodeFile(uri.path)
        }else{
            contentResolver.openInputStream(uri).use{input->
                if(input==null)throw IllegalStateException("Unable to open selected photo")
                BitmapFactory.decodeStream(input)
            }
        } ?: throw IllegalStateException("Selected file is not a readable image")
        FileOutputStream(out).use{output->
            if(!bitmap.compress(Bitmap.CompressFormat.JPEG,92,output))throw IllegalStateException("Unable to save photo")
        }
        bitmap.recycle()
        return out.absolutePath
    }
    private fun showSavedImage(path:String,iv:ImageView?){if(iv==null||path.isBlank())return;val f=File(path);if(f.exists()){iv.setImageBitmap(BitmapFactory.decodeFile(path));iv.visibility=View.VISIBLE}}

    private fun showSignatures(t:Tool){
        val l=base();l.addView(topBar("Signatures"){showAssign(t)});val sc=scroll();val f=base()
        f.addView(tv("Employee Signature",15f,GREEN,true));val es=SignatureView(this);f.addView(es,LinearLayout.LayoutParams(-1,160));f.addView(button("Clear",ORANGE){es.clear()})
        f.addView(tv("Supervisor Signature",15f,GREEN,true));val ss=SignatureView(this);f.addView(ss,LinearLayout.LayoutParams(-1,160));f.addView(button("Clear",ORANGE){ss.clear()})
        val notes=field(f,"Notes",t.notes.ifBlank{"Good condition. Assigned for site use."});sc.addView(f);l.addView(sc,LinearLayout.LayoutParams(-1,0,1f));l.addView(button("Save Item",GREEN){
            t.notes=notes.text.toString();t.employeeSignature=saveSignature(es,"employee");t.supervisorSignature=saveSignature(ss,"supervisor")
            val i=store.tools.indexOfFirst{it.number==t.number};if(i>=0)store.tools[i]=t else store.tools.add(t);store.save();showItemDetails(t)
        });setScreen(l)
    }
    private fun saveSignature(v:SignatureView,name:String):String{if(v.isBlank())return "";val dir=File(filesDir,"signatures");dir.mkdirs();val f=File(dir,"${name}_${System.currentTimeMillis()}.png");FileOutputStream(f).use{v.bitmap().compress(Bitmap.CompressFormat.PNG,100,it)};return f.absolutePath}

    private fun showLookup(){
        val l=base();l.addView(topBar("Look Up Item"){showHome()});val search=input("Search item number, make, model...");l.addView(search);val list=base();val sc=scroll();sc.addView(list);l.addView(sc,LinearLayout.LayoutParams(-1,0,1f))
        fun refresh(){list.removeAllViews();val q=search.text.toString().lowercase();store.tools.filter{q.isBlank()||"${it.number} ${it.make} ${it.model} ${it.serial}".lowercase().contains(q)}.forEach{t->list.addView(itemRow(t))}}
        search.addTextChangedListener(SimpleWatcher{refresh()});refresh();setScreen(l)
    }
    private fun itemRow(t:Tool)=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(6,6,6,6);background=GradientDrawable().apply{setColor(PANEL);setStroke(1,GREEN);cornerRadius=10f};val iv=ImageView(this@MainActivity).apply{scaleType=ImageView.ScaleType.CENTER_CROP};showSavedImage(t.photo,iv);addView(iv,LinearLayout.LayoutParams(78,78));addView(tv("${t.number}\n${t.make} ${t.model}\nS/N: ${t.serial}\n${t.assignedTo}",13f,TEXT,true),LinearLayout.LayoutParams(0,86,1f));setOnClickListener{showItemDetails(t)}}

    private fun showItemDetails(t:Tool){
        val l=base();l.addView(topBar("Item Details"){showLookup()});val sc=scroll();val f=base();val iv=ImageView(this).apply{scaleType=ImageView.ScaleType.CENTER_CROP};showSavedImage(t.photo,iv);f.addView(iv,LinearLayout.LayoutParams(-1,210));f.addView(tv("${t.number}\n${t.make} ${t.model}\nType: ${t.type}\nDescription: ${t.description}\nSerial Number: ${t.serial}\nEstimated Value: R %.2f\nAssigned To: ${t.assignedTo}\nCondition: ${t.condition}\nStatus: ${t.status}\nNotes: ${t.notes}",14f))
        f.addView(button("Edit Item",GREEN){showNewItem(t)});f.addView(button("Generate Individual PDF",BLUE){sharePdf(PdfMaker.item(this,t,store))});sc.addView(f);l.addView(sc,LinearLayout.LayoutParams(-1,0,1f));setScreen(l)
    }

    private fun showEmployees(){val l=base();l.addView(topBar("Employees"){showHome()});val sc=scroll();val f=base();f.addView(button("＋ Add Employee",GREEN){showEmployeeForm(null)});store.employees.forEach{e->val count=store.tools.count{it.assignedTo==e.name};f.addView(button("${e.name}\n${e.employeeNo} • ${e.position}\n$count Items",GREEN){showEmployeeDetails(e)})};sc.addView(f);l.addView(sc,LinearLayout.LayoutParams(-1,0,1f));setScreen(l)}
    private fun showEmployeeForm(existing:Employee?){
        employeeFormPhotoPath=existing?.photo ?: ""
        val l=base();l.addView(topBar(if(existing==null)"Add Employee" else "Edit Employee"){showEmployees()})
        val sc=scroll();val f=base()
        f.addView(tv("Employee Photo",15f,GREEN,true))
        employeeFormPhotoView=ImageView(this).apply{setBackgroundColor(FIELD);scaleType=ImageView.ScaleType.CENTER_CROP}
        f.addView(employeeFormPhotoView,LinearLayout.LayoutParams(-1,190))
        showSavedImage(employeeFormPhotoPath,employeeFormPhotoView)
        f.addView(button("📷  Take Employee Photo",BLUE){takePhoto(false)})
        f.addView(button("▣  Choose Employee Photo",BLUE){pickPhoto(false)})
        val n=field(f,"Full Name",existing?.name ?: "")
        val no=field(f,"Employee Number",existing?.employeeNo?:"")
        val p=field(f,"Position",existing?.position?:"Welder / Fabricator")
        val ph=field(f,"Contact Number",existing?.phone?:"")
        val em=field(f,"Email",existing?.email?:"")
        sc.addView(f);l.addView(sc,LinearLayout.LayoutParams(-1,0,1f))
        fun saveEmployee(addAnother:Boolean){
            val oldName=existing?.name
            val e=Employee(n.text.toString().trim(),no.text.toString().trim(),p.text.toString().trim(),ph.text.toString().trim(),em.text.toString().trim(),employeeFormPhotoPath)
            if(e.name.isBlank()||e.employeeNo.isBlank()){
                Toast.makeText(this,"Name and employee number are required",Toast.LENGTH_SHORT).show()
                return
            }
            val i=if(existing!=null)store.employees.indexOf(existing) else store.employees.indexOfFirst{it.employeeNo==e.employeeNo}
            if(i>=0)store.employees[i]=e else store.employees.add(e)
            if(oldName!=null && oldName!=e.name){
                store.tools.filter{it.assignedTo==oldName}.forEach{it.assignedTo=e.name;it.employeePhoto=e.photo}
            }
            store.tools.filter{it.assignedTo==e.name}.forEach{it.employeePhoto=e.photo}
            store.save()
            Toast.makeText(this,"Employee saved successfully.",Toast.LENGTH_SHORT).show()
            if(addAnother) showEmployeeForm(null) else showEmployees()
        }
        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        actions.addView(button("SAVE",GREEN){saveEmployee(false)},LinearLayout.LayoutParams(0,54,1f))
        actions.addView(button("SAVE & ADD ANOTHER",ORANGE){saveEmployee(true)},LinearLayout.LayoutParams(0,54,1f))
        l.addView(actions)
        setScreen(l)
    }

    private fun showEmployeeDetails(e:Employee){val l=base();l.addView(topBar("Employee Details"){showEmployees()});val sc=scroll();val f=base();val piv=ImageView(this).apply{scaleType=ImageView.ScaleType.CENTER_CROP;setBackgroundColor(FIELD)};f.addView(piv,LinearLayout.LayoutParams(-1,200));showSavedImage(e.photo,piv);f.addView(tv("${e.name}\n${e.employeeNo}\n${e.position}\n${e.phone}\n${e.email}",17f));f.addView(tv("Assigned Tools",16f,GREEN,true));store.tools.filter{it.assignedTo==e.name}.forEach{f.addView(tv("${it.number} • ${it.make} ${it.model} • R %.2f".format(it.value),14f))};f.addView(button("Generate Employee Tool List PDF",BLUE){sharePdf(PdfMaker.employee(this,e,store))});f.addView(button("Edit Employee",ORANGE){showEmployeeForm(e)});sc.addView(f);l.addView(sc,LinearLayout.LayoutParams(-1,0,1f));setScreen(l)}

    private fun showReports(){
        val l=base()
        l.addView(topBar("Reports"){showHome()})
        val sc=scroll(); val f=base()

        f.addView(tv("INDIVIDUAL ITEM REPORT",15f,GREEN,true))
        val itemNames=store.tools.map{"${it.number} • ${it.make} ${it.model}"}.ifEmpty{listOf("No items")}
        val itemSpinner=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,itemNames)}
        f.addView(itemSpinner)
        f.addView(button("GENERATE / SHARE ITEM REPORT",GREEN){
            val i=itemSpinner.selectedItemPosition
            if(store.tools.isNotEmpty()&&i>=0)sharePdf(PdfMaker.item(this,store.tools[i],store))
        })

        f.addView(tv("EMPLOYEE INVENTORY REPORT",15f,ORANGE,true))
        f.addView(tv("Select an employee. The report contains the employee photo and a list of assigned tools — no tool pictures.",12f,MUTED))
        val empNames=store.employees.map{"${it.name} • ${it.employeeNo} • ${it.position}"}.ifEmpty{listOf("No employees")}
        val empSpinner=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,empNames)}
        f.addView(empSpinner)
        val empPreview=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(8,8,8,8);background=GradientDrawable().apply{setColor(PANEL);setStroke(1,ORANGE);cornerRadius=10f}}
        val empPhoto=ImageView(this).apply{scaleType=ImageView.ScaleType.CENTER_CROP;setBackgroundColor(FIELD)}
        val empInfo=tv("",14f,TEXT,true)
        empPreview.addView(empPhoto,LinearLayout.LayoutParams(92,92));empPreview.addView(empInfo,LinearLayout.LayoutParams(0,92,1f))
        f.addView(empPreview)
        fun refreshEmployeeReportPreview(){
            val idx=empSpinner.selectedItemPosition
            val e=store.employees.getOrNull(idx)
            if(e==null){empInfo.text="No employee selected";empPhoto.setImageDrawable(null)}
            else{
                empInfo.text="${e.name}\n${e.employeeNo}\n${e.position}\n${store.tools.count{it.assignedTo==e.name}} assigned items"
                empPhoto.setImageDrawable(null);showSavedImage(e.photo,empPhoto)
            }
        }
        empSpinner.onItemSelectedListener=object:android.widget.AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent:android.widget.AdapterView<*>?,view:View?,position:Int,id:Long){refreshEmployeeReportPreview()}
            override fun onNothingSelected(parent:android.widget.AdapterView<*>?){refreshEmployeeReportPreview()}
        }
        refreshEmployeeReportPreview()
        f.addView(button("GENERATE / SHARE EMPLOYEE INVENTORY REPORT",ORANGE){
            val i=empSpinner.selectedItemPosition
            if(store.employees.isNotEmpty()&&i>=0)sharePdf(PdfMaker.employee(this,store.employees[i],store))
        })

        f.addView(tv("COMPLETE INVENTORY REPORT",15f,BLUE,true))
        f.addView(button("GENERATE / SHARE ALL ITEMS REPORT",BLUE){sharePdf(PdfMaker.all(this,store))})
        sc.addView(f);l.addView(sc,LinearLayout.LayoutParams(-1,0,1f));setScreen(l)
    }
    private fun showSync(){
        val l=base();l.addView(topBar("Live Synchronise"){showHome()})
        val sc=scroll();val f=base()
        f.addView(tv("☁  IDT LIVE SYNCHRONISATION",17f,GREEN,true).apply{gravity=Gravity.CENTER})
        f.addView(tv("Your IDT inventory is connected to Firebase. Changes made on this device can be synchronised automatically with your other authorised devices.",13f,MUTED))
        val status=tv("Checking Firebase connection…",14f,TEXT,true).apply{gravity=Gravity.CENTER}
        f.addView(status)
        f.addView(button("↻  REFRESH CLOUD DATA",GREEN){ cloud.pullNow{ runOnUiThread{ status.text=cloud.statusText(); showHome() } } })
        f.addView(button("☁  PUSH THIS DEVICE TO CLOUD",BLUE){ cloud.pushLocalSnapshot{ runOnUiThread{ status.text=cloud.statusText() } } })
        f.addView(tv("LIVE MODE",15f,ORANGE,true))
        f.addView(tv("When Firebase authentication is enabled, this screen will keep a real-time listener active. The app continues to keep a local copy so it can still open offline.",12f,MUTED))
        f.addView(tv("Cloud photos will be added in the next stage using Firebase Storage. Storage requires the Firebase Blaze plan; the inventory database itself can remain on the no-cost plan within its quotas.",12f,MUTED))
        sc.addView(f);l.addView(sc,LinearLayout.LayoutParams(-1,0,1f));setScreen(l)
        status.text=cloud.statusText()
    }

    private fun showSettings(){
        val l=base();l.addView(topBar("Settings"){showHome()});val sc=scroll();val f=base()
        f.addView(tv("I.D.T. STEELWORKS AND ENGINEERING\nWelding • Fabrication • Installation\nWestern Cape\niwardio@idtsteelwork.co.za",16f))
        f.addView(tv("DATA SAFETY",16f,GREEN,true))
        f.addView(tv("Create a backup before installing future updates. The backup contains your inventory and employee records.",13f,MUTED))
        f.addView(button("💾  BACKUP INVENTORY",GREEN){createBackup()})
        f.addView(button("♻  RESTORE INVENTORY",ORANGE){openRestore()})
        f.addView(button("☁  LIVE SYNCHRONISE",BLUE){showSync()})
        f.addView(tv("Keep your backup file somewhere safe before making major app changes.",12f,MUTED))
        f.addView(button("Clear all local inventory",RED){AlertDialog.Builder(this).setTitle("Clear inventory?").setMessage("Delete all local records?").setNegativeButton("Cancel",null).setPositiveButton("Clear"){_,_->store.tools.clear();store.employees.clear();store.save();showHome()}.show()})
        sc.addView(f);l.addView(sc,LinearLayout.LayoutParams(-1,0,1f));setScreen(l)
    }

    private fun createBackup(){
        try{
            val dir=File(cacheDir,"backup").apply{mkdirs()};val json=File(dir,"inventory.json")
            val root=JSONObject().apply{put("version",1);put("tools",store.toolsJson());put("employees",store.employeesJson())}
            json.writeText(root.toString())
            val out=File(getExternalFilesDir(null),"IDT-Inventory-Backup-${System.currentTimeMillis()}.zip")
            ZipOutputStream(FileOutputStream(out)).use{z->{z.putNextEntry(ZipEntry("inventory.json"));z.write(json.readBytes());z.closeEntry();
                val photoDir=File(filesDir,"photos");if(photoDir.exists())photoDir.listFiles()?.forEach{file->if(file.isFile){z.putNextEntry(ZipEntry("photos/${file.name}"));FileInputStream(file).use{it.copyTo(z)};z.closeEntry()}}
            }}
            val uri=FileProvider.getUriForFile(this,"${packageName}.fileprovider",out);startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="application/zip";putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)},"Save IDT Backup"))
        }catch(e:Exception){Toast.makeText(this,"Backup failed: ${e.message}",Toast.LENGTH_LONG).show()}
    }

    private fun createSyncPackage(){
        try{
            val out=File(getExternalFilesDir(null),"IDT-Sync-${SimpleDateFormat("yyyyMMdd-HHmmss",Locale.US).format(Date())}.zip")
            val root=JSONObject().apply{
                put("format","IDT_SYNC")
                put("version",2)
                put("createdAt",System.currentTimeMillis())
                put("tools",store.toolsJson())
                put("employees",store.employeesJson())
            }
            ZipOutputStream(FileOutputStream(out)).use{z->{
                z.putNextEntry(ZipEntry("sync.json"));z.write(root.toString().toByteArray());z.closeEntry()
                val photoDir=File(filesDir,"photos")
                if(photoDir.exists())photoDir.listFiles()?.forEach{file->if(file.isFile){
                    z.putNextEntry(ZipEntry("photos/${file.name}"));FileInputStream(file).use{it.copyTo(z)};z.closeEntry()
                }}
            }}
            val uri=FileProvider.getUriForFile(this,"${packageName}.fileprovider",out)
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="application/zip";putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)},"Send IDT Sync Package"))
        }catch(e:Exception){Toast.makeText(this,"Sync package failed: ${e.message}",Toast.LENGTH_LONG).show()}
    }

    private fun openSyncImport(){
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="application/zip";addCategory(Intent.CATEGORY_OPENABLE)},SYNC_OPEN)
    }

    private fun mergeSyncPackage(uri:Uri){
        val tmp=File(cacheDir,"sync.zip")
        contentResolver.openInputStream(uri)?.use{input->FileOutputStream(tmp).use{input.copyTo(it)}} ?: throw Exception("Could not open sync package")
        java.util.zip.ZipFile(tmp).use{zip->{
            val entry=zip.getEntry("sync.json") ?: throw Exception("Invalid IDT sync package")
            val root=JSONObject(zip.getInputStream(entry).bufferedReader().use{it.readText()})
            if(root.optString("format")!="IDT_SYNC") throw Exception("This is not an IDT Sync Package")
            val incomingTools=root.optJSONArray("tools") ?: JSONArray()
            val incomingEmployees=root.optJSONArray("employees") ?: JSONArray()
            val existingTools=store.tools.associateBy{it.number}.toMutableMap()
            for(i in 0 until incomingTools.length()){
                val o=incomingTools.getJSONObject(i);val n=o.optString("number");if(n.isBlank())continue
                existingTools[n]=Tool(n,o.optString("make"),o.optString("model"),o.optString("type"),o.optString("description"),o.optString("serial"),o.optDouble("value"),o.optString("assignedTo","Unassigned"),o.optString("photo"),o.optString("employeePhoto"),o.optString("condition","Good"),o.optString("status","Available"),o.optString("notes"),o.optString("employeeSignature"),o.optString("supervisorSignature"))
            }
            val existingEmployees=store.employees.associateBy{it.employeeNo}.toMutableMap()
            for(i in 0 until incomingEmployees.length()){
                val o=incomingEmployees.getJSONObject(i);val n=o.optString("employeeNo");if(n.isBlank())continue
                existingEmployees[n]=Employee(o.optString("name"),n,o.optString("position"),o.optString("phone"),o.optString("email"),o.optString("photo"))
            }
            store.tools.clear();store.tools.addAll(existingTools.values.sortedBy{it.number})
            store.employees.clear();store.employees.addAll(existingEmployees.values.sortedBy{it.employeeNo})
            // Copy photos into this device and rewrite stored absolute paths to this device's photo directory.
            val photoDir=File(filesDir,"photos").apply{mkdirs()}
            zip.entries().asSequence().filter{it.name.startsWith("photos/")&&!it.isDirectory}.forEach{e->{
                val name=File(e.name).name;val out=File(photoDir,name);zip.getInputStream(e).use{ins->FileOutputStream(out).use{ins.copyTo(it)}}
            }}
            fun localPhotoPath(old:String):String{if(old.isBlank())return "";val name=File(old).name;val local=File(photoDir,name);return if(local.exists())local.absolutePath else old}
            store.tools.forEach{it.photo=localPhotoPath(it.photo);it.employeePhoto=localPhotoPath(it.employeePhoto);it.employeeSignature=localPhotoPath(it.employeeSignature);it.supervisorSignature=localPhotoPath(it.supervisorSignature)}
            store.employees.forEach{it.photo=localPhotoPath(it.photo)}
            store.save()
        }}
        Toast.makeText(this,"Sync imported and merged successfully.",Toast.LENGTH_LONG).show();showHome()
    }

    private fun openRestore(){
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="application/zip";addCategory(Intent.CATEGORY_OPENABLE)},BACKUP_OPEN)
    }

    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Uri?){
        super.onActivityResult(requestCode,resultCode,data)
        if(resultCode!=RESULT_OK||data==null)return
        if(requestCode==SYNC_OPEN){
            try{mergeSyncPackage(data)}catch(e:Exception){Toast.makeText(this,"Sync failed: ${e.message}",Toast.LENGTH_LONG).show()}
            return
        }
        if(requestCode!=BACKUP_OPEN)return
        try{
            val tmp=File(cacheDir,"restore.zip");contentResolver.openInputStream(data)?.use{input->FileOutputStream(tmp).use{input.copyTo(it)}}
            java.util.zip.ZipFile(tmp).use{zip->{val entry=zip.getEntry("inventory.json")?:throw Exception("Invalid IDT backup");val root=JSONObject(zip.getInputStream(entry).bufferedReader().use{it.readText()});store.replaceFromJson(root.getJSONArray("tools"),root.getJSONArray("employees"));
                val photoDir=File(filesDir,"photos").apply{mkdirs()}
                zip.entries().asSequence().filter{it.name.startsWith("photos/")&&!it.isDirectory}.forEach{e->{val name=File(e.name).name;val out=File(photoDir,name);zip.getInputStream(e).use{ins->FileOutputStream(out).use{ins.copyTo(it)}}}
                fun localPhotoPath(old:String):String{if(old.isBlank())return "";val name=File(old).name;val local=File(photoDir,name);return if(local.exists())local.absolutePath else old}
                store.tools.forEach{it.photo=localPhotoPath(it.photo);it.employeePhoto=localPhotoPath(it.employeePhoto);it.employeeSignature=localPhotoPath(it.employeeSignature);it.supervisorSignature=localPhotoPath(it.supervisorSignature)}
                store.employees.forEach{it.photo=localPhotoPath(it.photo)}
                store.save()
            }}
            Toast.makeText(this,"Inventory restored successfully.",Toast.LENGTH_LONG).show();showHome()
        }catch(e:Exception){Toast.makeText(this,"Restore failed: ${e.message}",Toast.LENGTH_LONG).show()}
    }

    fun showHomeFromCloud(){ showHome() }

    private fun sharePdf(file:File){val uri=FileProvider.getUriForFile(this,"${packageName}.fileprovider",file);startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="application/pdf";putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)},"Share IDT PDF"))}
}

private class SimpleWatcher(val fn:()->Unit):android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){fn()};override fun afterTextChanged(s:android.text.Editable?){}}

class SignatureView(ctx:Context):View(ctx){private val path=Path();private val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.BLACK;style=Paint.Style.STROKE;strokeWidth=5f;strokeCap=Paint.Cap.ROUND};private var down=false;init{setBackgroundColor(Color.WHITE)};override fun onDraw(c:Canvas){c.drawColor(Color.WHITE);c.drawPath(path,paint)};override fun onTouchEvent(e:android.view.MotionEvent):Boolean{when(e.action){MotionEvent.ACTION_DOWN->path.moveTo(e.x,e.y);MotionEvent.ACTION_MOVE->path.lineTo(e.x,e.y);MotionEvent.ACTION_UP->invalidate()};invalidate();return true};fun clear(){path.reset();invalidate()};fun isBlank()=path.isEmpty;fun bitmap():Bitmap{val b=Bitmap.createBitmap(width.coerceAtLeast(1),height.coerceAtLeast(1),Bitmap.Config.ARGB_8888);Canvas(b).also{it.drawColor(Color.WHITE);it.drawPath(path,paint)};return b}}

class Store(private val ctx:Context){val tools=mutableListOf<Tool>();val employees=mutableListOf<Employee>();var onSaved:(()->Unit)?=null;private val p=ctx.getSharedPreferences("idt_inventory",Context.MODE_PRIVATE)
    init{load();if(tools.isEmpty()&&employees.isEmpty())seed()}
    private fun seed(){employees.addAll(listOf(Employee("Iwardio Du Toit","IDT-001","Manager"),Employee("Johan Smith","IDT-003","Welder / Fabricator"),Employee("Pieter Jacobs","IDT-004","Installer"),Employee("Mark Daniels","IDT-005","General Worker")));tools.addAll(listOf(Tool("IDT-001","Makita","DHR243Z","Rotary Hammer","18V Cordless Rotary Hammer Drill with 3 modes","A1234567",3699.0,"Johan Smith"),Tool("IDT-002","DeWalt","DWE7492","Table Saw","Heavy duty table saw","B7654321",8500.0,"Mark Daniels"),Tool("IDT-003","Bosch","GWS 2200","Angle Grinder","Professional angle grinder","C9876543",2450.0,"Pieter Jacobs"),Tool("IDT-004","Lincoln","PowerMIG 220","Welding Machine","Portable welding machine","L1122334",9500.0,"Iwardio Du Toit"),Tool("IDT-005","Makita","DTD152","Impact Driver","18V impact driver","M2233445","Johan Smith".let{2150.0})));save()}
    fun save(){val ta=JSONArray();tools.forEach{ta.put(JSONObject().apply{put("number",it.number);put("make",it.make);put("model",it.model);put("type",it.type);put("description",it.description);put("serial",it.serial);put("value",it.value);put("assignedTo",it.assignedTo);put("photo",it.photo);put("employeePhoto",it.employeePhoto);put("condition",it.condition);put("status",it.status);put("notes",it.notes);put("employeeSignature",it.employeeSignature);put("supervisorSignature",it.supervisorSignature)})};val ea=JSONArray();employees.forEach{ea.put(JSONObject().apply{put("name",it.name);put("employeeNo",it.employeeNo);put("position",it.position);put("phone",it.phone);put("email",it.email);put("photo",it.photo)})};p.edit().putString("tools",ta.toString()).putString("employees",ea.toString()).apply();onSaved?.invoke()}
    fun toolsJson():JSONArray=JSONArray().apply{tools.forEach{put(JSONObject().apply{put("number",it.number);put("make",it.make);put("model",it.model);put("type",it.type);put("description",it.description);put("serial",it.serial);put("value",it.value);put("assignedTo",it.assignedTo);put("photo",it.photo);put("employeePhoto",it.employeePhoto);put("condition",it.condition);put("status",it.status);put("notes",it.notes);put("employeeSignature",it.employeeSignature);put("supervisorSignature",it.supervisorSignature)})}}
    fun employeesJson():JSONArray=JSONArray().apply{employees.forEach{put(JSONObject().apply{put("name",it.name);put("employeeNo",it.employeeNo);put("position",it.position);put("phone",it.phone);put("email",it.email);put("photo",it.photo)})}}
    fun replaceFromJson(ta:JSONArray,ea:JSONArray,notify:Boolean=true){
        tools.clear();employees.clear()
        for(i in 0 until ta.length()){val o=ta.getJSONObject(i);tools.add(Tool(o.optString("number"),o.optString("make"),o.optString("model"),o.optString("type"),o.optString("description"),o.optString("serial"),o.optDouble("value"),o.optString("assignedTo","Unassigned"),o.optString("photo"),o.optString("employeePhoto"),o.optString("condition","Good"),o.optString("status","Available"),o.optString("notes"),o.optString("employeeSignature"),o.optString("supervisorSignature")))}
        for(i in 0 until ea.length()){val o=ea.getJSONObject(i);employees.add(Employee(o.optString("name"),o.optString("employeeNo"),o.optString("position"),o.optString("phone"),o.optString("email"),o.optString("photo")))}
        val callback=onSaved
        if(!notify)onSaved=null
        save()
        onSaved=callback
    }

    private fun load(){try{JSONArray(p.getString("tools","[]")).also{for(i in 0 until it.length()){val o=it.getJSONObject(i);tools.add(Tool(o.optString("number"),o.optString("make"),o.optString("model"),o.optString("type"),o.optString("description"),o.optString("serial"),o.optDouble("value"),o.optString("assignedTo","Unassigned"),o.optString("photo"),o.optString("employeePhoto"),o.optString("condition","Good"),o.optString("status","Available"),o.optString("notes"),o.optString("employeeSignature"),o.optString("supervisorSignature")))}};JSONArray(p.getString("employees","[]")).also{for(i in 0 until it.length()){val o=it.getJSONObject(i);employees.add(Employee(o.optString("name"),o.optString("employeeNo"),o.optString("position"),o.optString("phone"),o.optString("email"),o.optString("photo")))}}}catch(_:Exception){tools.clear();employees.clear()}}
}

private class FirebaseCloudSync(private val ctx:Context, private val store:Store){
    private val auth=FirebaseAuth.getInstance()
    private val db=FirebaseFirestore.getInstance()
    private val doc=db.collection("companies").document("IDT").collection("inventory").document("current")
    private var started=false
    private var applyingRemote=false
    @Volatile private var status="Starting Firebase…"

    fun statusText():String=status

    fun start(){
        if(started)return
        started=true
        if(auth.currentUser!=null){attachListener();loadOrSeedCloud();return}
        status="Signing in to Firebase…"
        auth.signInAnonymously().addOnSuccessListener{
            status="Firebase connected"
            attachListener()
            loadOrSeedCloud()
        }.addOnFailureListener{
            status="Firebase authentication is not enabled yet"
        }
    }

    private fun loadOrSeedCloud(){
        doc.get().addOnSuccessListener{snapshot->
            if(snapshot.exists()){
                pullNow()
            }else{
                pushLocalSnapshot()
            }
        }.addOnFailureListener{
            status="Cloud check failed: ${it.message ?: "unknown error"}"
        }
    }

    private fun attachListener(){
        doc.addSnapshotListener{snapshot,error->
            if(error!=null){status="Cloud error: ${error.message ?: "unknown error"}";return@addSnapshotListener}
            if(snapshot==null||!snapshot.exists()){status="Firebase connected — no cloud inventory yet";return@addSnapshotListener}
            if(applyingRemote)return@addSnapshotListener
            try{
                val tools=snapshot.get("tools") as? List<*> ?: emptyList<Any>()
                val employees=snapshot.get("employees") as? List<*> ?: emptyList<Any>()
                val ta=JSONArray();tools.forEach{v-> if(v is Map<*,*>){ta.put(JSONObject(v.mapKeys{it.key.toString()}.mapValues{it.value}))}}
                val ea=JSONArray();employees.forEach{v-> if(v is Map<*,*>){ea.put(JSONObject(v.mapKeys{it.key.toString()}.mapValues{it.value}))}}
                applyingRemote=true
                store.replaceFromJson(ta,ea,false)
                applyingRemote=false
                status="Live — cloud data updated ${SimpleDateFormat("HH:mm:ss",Locale.US).format(Date())}"
                if(ctx is MainActivity)ctx.runOnUiThread{ctx.showHomeFromCloud()}
            }catch(e:Exception){applyingRemote=false;status="Cloud data error: ${e.message}"}
        }
    }

    fun pushLocalSnapshot(onDone:(()->Unit)?=null){
        if(applyingRemote){onDone?.invoke();return}
        if(auth.currentUser==null){status="Waiting for Firebase authentication";onDone?.invoke();return}
        val tools=store.tools.map{mapOf("number" to it.number,"make" to it.make,"model" to it.model,"type" to it.type,"description" to it.description,"serial" to it.serial,"value" to it.value,"assignedTo" to it.assignedTo,"photo" to it.photo,"employeePhoto" to it.employeePhoto,"condition" to it.condition,"status" to it.status,"notes" to it.notes,"employeeSignature" to it.employeeSignature,"supervisorSignature" to it.supervisorSignature)}
        val employees=store.employees.map{mapOf("name" to it.name,"employeeNo" to it.employeeNo,"position" to it.position,"phone" to it.phone,"email" to it.email,"photo" to it.photo)}
        status="Uploading inventory to Firebase…"
        doc.set(mapOf("tools" to tools,"employees" to employees,"updatedAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()),SetOptions.merge())
            .addOnSuccessListener{status="Live — cloud updated ${SimpleDateFormat("HH:mm:ss",Locale.US).format(Date())}";onDone?.invoke()}
            .addOnFailureListener{status="Cloud upload failed: ${it.message ?: "unknown error"}";onDone?.invoke()}
    }

    fun pullNow(onDone:(()->Unit)?=null){
        doc.get().addOnSuccessListener{snap->
            if(!snap.exists()){status="No cloud inventory found";onDone?.invoke();return@addOnSuccessListener}
            try{
                val tools=snap.get("tools") as? List<*> ?: emptyList<Any>()
                val employees=snap.get("employees") as? List<*> ?: emptyList<Any>()
                val ta=JSONArray();tools.forEach{v->if(v is Map<*,*>){ta.put(JSONObject(v.mapKeys{it.key.toString()}.mapValues{it.value}))}}
                val ea=JSONArray();employees.forEach{v->if(v is Map<*,*>){ea.put(JSONObject(v.mapKeys{it.key.toString()}.mapValues{it.value}))}}
                applyingRemote=true;store.replaceFromJson(ta,ea,false);applyingRemote=false
                status="Cloud inventory downloaded"
            }catch(e:Exception){applyingRemote=false;status="Cloud download failed: ${e.message}"}
            onDone?.invoke()
        }.addOnFailureListener{status="Cloud download failed: ${it.message ?: "unknown error"}";onDone?.invoke()}
    }
}

private object PdfMaker{
    private const val W=595; private const val H=842
    private fun paint(color:Int=Color.BLACK,size:Float=11f,bold:Boolean=false)=Paint(Paint.ANTI_ALIAS_FLAG).apply{this.color=color;textSize=size;typeface=if(bold)Typeface.DEFAULT_BOLD else Typeface.DEFAULT}
    private fun header(c:Canvas,p:Paint,title:String){
        p.color=Color.BLACK;c.drawRect(0f,0f,W.toFloat(),62f,p)
        p.color=GREEN;p.textSize=17f;p.typeface=Typeface.DEFAULT_BOLD;c.drawText("I.D.T. STEELWORKS AND ENGINEERING",18f,24f,p)
        p.color=Color.WHITE;p.textSize=9f;p.typeface=Typeface.DEFAULT;c.drawText("Welding | Fabrication | Installation",18f,39f,p)
        p.color=ORANGE;p.textSize=12f;p.typeface=Typeface.DEFAULT_BOLD;c.drawText(title,18f,55f,p)
    }
    private fun drawPhoto(c:Canvas,path:String,left:Float,top:Float,right:Float,bottom:Float,label:String="NO PHOTO"){
        val border=paint(Color.LTGRAY,1f);border.style=Paint.Style.STROKE;c.drawRect(left,top,right,bottom,border)
        if(path.isNotBlank()){
            val file=File(path);if(file.exists()){
                val opts=BitmapFactory.Options().apply{inPreferredConfig=Bitmap.Config.ARGB_8888}
                val b=BitmapFactory.decodeFile(file.absolutePath,opts)
                if(b!=null){c.drawBitmap(b,null,RectF(left+2,top+2,right-2,bottom-2),Paint(Paint.ANTI_ALIAS_FLAG));b.recycle();return}
            }
        }
        val p=paint(Color.GRAY,10f,true);p.textAlign=Paint.Align.CENTER;c.drawText(label,(left+right)/2f,(top+bottom)/2f,p);p.textAlign=Paint.Align.LEFT
    }
    private fun wrap(text:String,maxChars:Int):List<String>{
        if(text.isBlank())return listOf("")
        val words=text.replace("\n"," ").split(" ").filter{it.isNotBlank()};val out=mutableListOf<String>();var line=""
        for(w in words){if((line+" "+w).trim().length>maxChars&&line.isNotBlank()){out.add(line.trim());line=w}else line=(line+" "+w).trim()}
        if(line.isNotBlank())out.add(line.trim());return out
    }
    private fun money(v:Double)=String.format(Locale.US,"R %,.2f",v)

    fun item(ctx:Context,t:Tool,s:Store):File{
        val d=android.graphics.pdf.PdfDocument();val page=d.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(W,H,1).create());val c=page.canvas;val p=paint();header(c,p,"TOOL INVENTORY REPORT - INDIVIDUAL ITEM")
        var y=92f
        val rows=listOf(
            "Item Number" to t.number,"Make" to t.make,"Model" to t.model,"Type" to t.type,"Description" to t.description,
            "Serial Number" to t.serial,"Estimated Value" to money(t.value),"Assigned To" to t.assignedTo,
            "Condition" to t.condition,"Status" to t.status,"Notes" to t.notes
        )
        p.textSize=11f
        rows.forEach{(label,value)->
            c.drawText("$label:",18f,y,p)
            val lines=wrap(value,42)
            lines.forEachIndexed{idx,line->c.drawText(line,115f,y+idx*16f,p)}
            y+=23f+((lines.size-1)*16f)
        }
        drawPhoto(c,t.photo,350f,88f,575f,300f,"NO ITEM PHOTO")
        p.typeface=Typeface.DEFAULT_BOLD;p.textSize=10f;c.drawText("Individual Item Photo",350f,315f,p)
        p.typeface=Typeface.DEFAULT;p.textSize=10f;c.drawText("Employee Signature",25f,680f,p);c.drawText("Supervisor Signature",325f,680f,p)
        drawPhoto(c,t.employeeSignature,20f,690f,275f,775f,"NO SIGNATURE");drawPhoto(c,t.supervisorSignature,320f,690f,575f,775f,"NO SIGNATURE")
        d.finishPage(page);return write(ctx,d,"IDT-Individual-${t.number}.pdf")
    }

    fun employee(ctx:Context,e:Employee,s:Store):File{
        val assigned=s.tools.filter{it.assignedTo==e.name};val d=android.graphics.pdf.PdfDocument();var pageNo=1;var page=d.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(W,H,pageNo).create());var c=page.canvas;var p=paint();header(c,p,"EMPLOYEE INVENTORY REPORT")
        drawPhoto(c,e.photo,18f,75f,125f,182f,"NO EMPLOYEE PHOTO")
        p.typeface=Typeface.DEFAULT_BOLD;p.textSize=15f;c.drawText(e.name,145f,96f,p);p.typeface=Typeface.DEFAULT;p.textSize=11f;c.drawText("Employee ID: ${e.employeeNo}",145f,116f,p);c.drawText("Position: ${e.position}",145f,134f,p);if(e.phone.isNotBlank())c.drawText("Contact: ${e.phone}",145f,152f,p);if(e.email.isNotBlank())c.drawText("Email: ${e.email}",145f,170f,p)
        p.typeface=Typeface.DEFAULT_BOLD;p.textSize=13f;c.drawText("ASSIGNED TOOL INVENTORY",18f,215f,p)
        val headers=listOf("#","Item Number","Make / Model","Type","Serial Number","Value")
        fun drawTableHeader(y:Float){p.color=Color.BLACK;c.drawRect(15f,y-16f,580f,y+9f,p);p.color=Color.WHITE;p.textSize=8f;p.typeface=Typeface.DEFAULT_BOLD;c.drawText("#",20f,y,p);c.drawText("Item Number",38f,y,p);c.drawText("Make / Model",120f,y,p);c.drawText("Type",255f,y,p);c.drawText("Serial Number",350f,y,p);c.drawText("Value",490f,y,p);p.color=Color.BLACK;p.typeface=Typeface.DEFAULT}
        var y=240f;drawTableHeader(y);y+=28f
        if(assigned.isEmpty()){p.textSize=11f;c.drawText("No tools are currently assigned to this employee.",20f,y,p);y+=25f}
        assigned.forEachIndexed{idx,t->
            if(y>760f){d.finishPage(page);pageNo++;page=d.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(W,H,pageNo).create());c=page.canvas;p=paint();header(c,p,"EMPLOYEE INVENTORY REPORT — CONTINUED");y=90f;drawTableHeader(y);y+=28f}
            p.textSize=8.5f;p.color=Color.BLACK
            c.drawText("${idx+1}",20f,y,p);c.drawText(t.number.take(14),38f,y,p);c.drawText("${t.make} ${t.model}".take(24),120f,y,p);c.drawText(t.type.take(16),255f,y,p);c.drawText(t.serial.take(18),350f,y,p);c.drawText(money(t.value),490f,y,p)
            p.color=0xFFD0D0D0.toInt();p.strokeWidth=0.5f;c.drawLine(18f,y+9f,577f,y+9f,p);p.color=Color.BLACK;y+=28f
        }
        p.typeface=Typeface.DEFAULT_BOLD;p.textSize=11f;c.drawText("Total Assigned Items: ${assigned.size}",18f,795f,p);c.drawText("Total Inventory Value: ${money(assigned.sumOf{it.value})}",330f,795f,p)
        d.finishPage(page);return write(ctx,d,"IDT-Employee-${e.employeeNo}.pdf")
    }

    fun all(ctx:Context,s:Store):File{
        val d=android.graphics.pdf.PdfDocument();var pageNo=1;var page=d.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(W,H,pageNo).create());var c=page.canvas;var p=paint();header(c,p,"COMPLETE TOOL INVENTORY REPORT");var y=90f
        p.color=Color.BLACK;p.textSize=8f;p.typeface=Typeface.DEFAULT_BOLD;c.drawText("#   Item Number   Make   Model   Type   Serial   Assigned   Value",15f,y,p);y+=20f;p.typeface=Typeface.DEFAULT
        s.tools.forEachIndexed{idx,t->if(y>790f){d.finishPage(page);pageNo++;page=d.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(W,H,pageNo).create());c=page.canvas;p=paint();header(c,p,"COMPLETE TOOL INVENTORY REPORT — CONTINUED");y=90f};c.drawText("${idx+1}   ${t.number}   ${t.make.take(8)}   ${t.model.take(10)}   ${t.type.take(12)}   ${t.serial.take(10)}   ${t.assignedTo.take(14)}   ${money(t.value)}",15f,y,p);y+=25f}
        d.finishPage(page);return write(ctx,d,"IDT-Complete-Inventory.pdf")
    }
    private fun write(ctx:Context,d:android.graphics.pdf.PdfDocument,name:String):File{val dir=File(ctx.cacheDir,"reports");dir.mkdirs();val f=File(dir,name);FileOutputStream(f).use{d.writeTo(it)};d.close();return f}
}
