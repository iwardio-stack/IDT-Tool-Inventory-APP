# IDT Tool Inventory — Firebase Live Sync

This build starts from the V14 IDT Tool Inventory Android app and replaces the old manual ZIP sync screen with a Firebase Cloud Firestore live-sync layer.

## Firebase project
- Project ID: `idt-tool-inventory`
- Android package: `com.idt.toolinventory`
- Firestore database: `(default)`
- Firestore region: `africa-south1` (Johannesburg)

## Included
- Existing IDT inventory UI and reports
- Local offline SharedPreferences copy
- Firebase Authentication (anonymous sign-in for this first live-sync build)
- Cloud Firestore live listener
- Automatic upload after local saves
- Pull/refresh cloud inventory
- Firebase `google-services.json`

## Firebase console steps before testing
1. Open Firebase Console → Security → Authentication.
2. Open the Sign-in method tab.
3. Enable **Anonymous** sign-in and save.
4. Open Firestore → Rules.
5. Replace the rules with the contents of `firestore.rules` and Publish.

The app uses anonymous authentication only as an initial live-sync bridge. For a production business deployment, replace it with permanent employee/company accounts and stricter rules.

## Build
GitHub Actions is configured to build the debug APK using JDK 17 and Gradle 8.9.

Firebase Android setup follows the official Google services Gradle plugin and Firebase Android BoM setup.
