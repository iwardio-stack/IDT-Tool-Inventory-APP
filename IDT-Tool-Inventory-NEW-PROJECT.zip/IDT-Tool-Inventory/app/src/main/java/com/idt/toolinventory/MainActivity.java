package com.idt.toolinventory;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.util.*;

public class MainActivity extends Activity {
    static final int GREEN=Color.rgb(124,255,0), ORANGE=Color.rgb(255,105,0), BG=Color.rgb(5,5,5), CARD=Color.rgb(20,20,20), GREY=Color.rgb(175,175,175);
    LinearLayout root, content; android.content.SharedPreferences prefs; ArrayList<JSONObject> items=new ArrayList<>(), employees=new ArrayList<>();
    EditText search;
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    TextView tv(String s,float size,int color){ TextView t=new TextView(this); t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setPadding(dp(10),dp(8),dp(10),dp(8)); return t; }
    GradientDrawable bg(int color,float r){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(r));g.setStroke(dp(1),Color.DKGRAY);return g;}
    Button btn(String s,int color){Button b=new Button(this);b.setText(s);b.setTextColor(Color.BLACK);b.setTextSize(15);b.setAllCaps(false);b.setBackground(bg(color,8));b.setPadding(dp(8),dp(4),dp(8),dp(4));return b;}
    @Override public void onCreate(Bundle b){super.onCreate(b); prefs=getSharedPreferences("idt_inventory",0); load(); build(); showHome();}
    void load(){try{JSONArray a=new JSONArray(prefs.getString("items","[]"));for(int i=0;i<a.length();i++)items.add(a.getJSONObject(i));JSONArray e=new JSONArray(prefs.getString("employees","[]"));for(int i=0;i<e.length();i++)employees.add(e.getJSONObject(i));}catch(Exception ignored){}}
    void save(){try{JSONArray a=new JSONArray();for(JSONObject o:items)a.put(o);JSONArray e=new JSONArray();for(JSONObject o:employees)e.put(o);prefs.edit().putString("items",a.toString()).putString("employees",e.toString()).apply();}catch(Exception ignored){}}
    void build(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(10),dp(4),dp(8),dp(4));
        TextView title=tv("IDT TOOL INVENTORY",20,GREEN);title.setTypeface(null,1);bar.addView(title,new LinearLayout.LayoutParams(0,dp(54),1));
        Button gear=btn("⚙",Color.DKGRAY);gear.setOnClickListener(v->settings());bar.addView(gear,new LinearLayout.LayoutParams(dp(54),dp(50)));root.addView(bar);
        ScrollView sv=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(10),0,dp(10),dp(20));sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
    }
    void clear(){content.removeAllViews();}
    void showHome(){clear();
        ImageView logo=new ImageView(this);logo.setImageResource(com.idt.toolinventory.R.drawable.idt_logo);logo.setAdjustViewBounds(true);logo.setPadding(dp(30),dp(6),dp(30),dp(6));content.addView(logo,new LinearLayout.LayoutParams(-1,dp(145)));
        TextView sub=tv("WELDING • FABRICATION • INSTALLATION",12,ORANGE);sub.setGravity(Gravity.CENTER);content.addView(sub);
        LinearLayout stats=new LinearLayout(this);stats.setOrientation(LinearLayout.VERTICAL);content.addView(stats);
        LinearLayout r1=new LinearLayout(this);stats.addView(r1);card(r1,"🔧\nTOTAL ITEMS\n"+items.size(),GREEN);card(r1,"💰\nESTIMATED VALUE\nR "+money(totalValue()),GREEN);
        LinearLayout r2=new LinearLayout(this);stats.addView(r2);card(r2,"👤\nASSIGNED\n"+assignedCount(),GREEN);card(r2,"👥\nUNASSIGNED\n"+(items.size()-assignedCount()),ORANGE);
        content.addView(tv("ITEMS BY TYPE",15,GREEN));
        HashMap<String,Integer> count=new HashMap<>();HashMap<String,Double> vals=new HashMap<>();for(JSONObject o:items){String ty=o.optString("type","Other Equipment");count.put(ty,count.getOrDefault(ty,0)+1);vals.put(ty,vals.getOrDefault(ty,0.0)+o.optDouble("value",0));}
        for(String ty:count.keySet()){TextView row=tv(ty+"    "+count.get(ty)+"    R "+money(vals.get(ty)),14,Color.WHITE);row.setBackground(bg(CARD,6));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(40));p.setMargins(0,dp(2),0,dp(2));content.addView(row,p);}
        nav("＋  New Item",GREEN,v->newItem());nav("⌕  Look Up Item",GREEN,v->lookup());nav("👥  Employees",ORANGE,v->employeesScreen());nav("▣  Reports",ORANGE,v->reports());nav("⚙  Settings",Color.DKGRAY,v->settings());
    }
    void card(LinearLayout row,String s,int c){TextView x=tv(s,14,c);x.setGravity(Gravity.CENTER);x.setTypeface(null,1);x.setBackground(bg(CARD,8));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(78),1);p.setMargins(dp(2),dp(3),dp(2),dp(3));row.addView(x,p);}
    void nav(String s,int c,View.OnClickListener l){Button b=btn(s,c);b.setOnClickListener(l);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(50));p.setMargins(0,dp(5),0,0);content.addView(b,p);}
    String money(double n){return String.format(Locale.US,"%,.2f",n);}
    double totalValue(){double n=0;for(JSONObject o:items)n+=o.optDouble("value",0);return n;}
    int assignedCount(){int n=0;for(JSONObject o:items)if(!o.optString("employee").isEmpty())n++;return n;}
    EditText field(LinearLayout p,String hint){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(Color.GRAY);e.setTextColor(Color.WHITE);e.setSingleLine(false);e.setPadding(dp(12),0,dp(12),0);e.setBackground(bg(Color.rgb(22,28,32),6));p.addView(e,new LinearLayout.LayoutParams(-1,dp(48)));return e;}
    void newItem(){clear();header("←  NEW ITEM",()->showHome());final EditText no=field(content,"Item Number * (e.g. IDT-001)"),make=field(content,"Make *"),model=field(content,"Model Number"),type=field(content,"Type *"),desc=field(content,"Description *"),serial=field(content,"Serial Number"),value=field(content,"Estimated Value (R)");
        Button next=btn("Next  →",ORANGE);next.setOnClickListener(v->{if(no.getText().toString().trim().isEmpty()||make.getText().toString().trim().isEmpty()){toast("Item Number and Make are required");return;}JSONObject o=new JSONObject();try{o.put("number",no.getText().toString());o.put("make",make.getText().toString());o.put("model",model.getText().toString());o.put("type",type.getText().toString().isEmpty()?"Other Equipment":type.getText().toString());o.put("description",desc.getText().toString());o.put("serial",serial.getText().toString());o.put("value",Double.parseDouble(value.getText().toString().isEmpty()?"0":value.getText().toString()));o.put("employee","");o.put("notes","");items.add(o);save();employeeAndPhotos(o);}catch(Exception ex){toast("Please check the value field");}});content.addView(next,new LinearLayout.LayoutParams(-1,dp(54)));
    }
    void employeeAndPhotos(JSONObject o){clear();header("←  ASSIGN & PHOTOS",()->showHome());content.addView(tv("ASSIGN TO EMPLOYEE",16,GREEN));Spinner sp=new Spinner(this);ArrayList<String> names=new ArrayList<>();names.add("Unassigned");for(JSONObject e:employees)names.add(e.optString("name",""));ArrayAdapter<String>a=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,names);sp.setAdapter(a);content.addView(sp,new LinearLayout.LayoutParams(-1,dp(50)));content.addView(tv("PHOTO SUPPORT WILL BE ADDED IN PHASE 2",13,GREY));Button next=btn("Next →",ORANGE);next.setOnClickListener(v->{try{int pos=sp.getSelectedItemPosition();o.put("employee",pos==0?"":names.get(pos));save();signSave(o);}catch(Exception ignored){}});content.addView(next,new LinearLayout.LayoutParams(-1,dp(54)));}
    void signSave(JSONObject o){clear();header("←  NOTES & SAVE",()->employeeAndPhotos(o));EditText notes=field(content,"Notes / condition / site information");Button saveb=btn("✓  SAVE ITEM",GREEN);saveb.setOnClickListener(v->{try{o.put("notes",notes.getText().toString());save();toast("Item saved");showHome();}catch(Exception ignored){}});content.addView(saveb,new LinearLayout.LayoutParams(-1,dp(56)));}
    void lookup(){clear();header("←  LOOK UP ITEM",()->showHome());search=field(content,"Search item number, make, model or serial...");search.setSingleLine(true);search.setOnKeyListener((v,k,e)->{renderItems(search.getText().toString());return false;});renderItems("");}
    void renderItems(String q){while(content.getChildCount()>2)content.removeViewAt(2);for(JSONObject o:items){String s=(o.optString("number")+" "+o.optString("make")+" "+o.optString("model")+" "+o.optString("serial")).toLowerCase();if(!s.contains(q.toLowerCase()))continue;TextView t=tv(o.optString("number")+"\n"+o.optString("make")+" "+o.optString("model")+"\nS/N: "+o.optString("serial")+"\n"+(o.optString("employee").isEmpty()?"UNASSIGNED":"Assigned: "+o.optString("employee"))+"    R "+money(o.optDouble("value",0)),15,GREEN);t.setBackground(bg(CARD,8));t.setOnClickListener(v->itemDetail(o));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(105));p.setMargins(0,dp(5),0,0);content.addView(t,p);}}
    void itemDetail(JSONObject o){new AlertDialog.Builder(this).setTitle(o.optString("number")).setMessage("Make: "+o.optString("make")+"\nModel: "+o.optString("model")+"\nType: "+o.optString("type")+"\nSerial: "+o.optString("serial")+"\nValue: R "+money(o.optDouble("value",0))+"\nAssigned to: "+(o.optString("employee").isEmpty()?"Unassigned":o.optString("employee"))+"\n\n"+o.optString("description")+"\n\n"+o.optString("notes")).setPositiveButton("Close",null).setNegativeButton("Delete",(d,w)->{items.remove(o);save();lookup();}).show();}
    void employeesScreen(){clear();header("←  EMPLOYEES",()->showHome());Button add=btn("＋ Add Employee",ORANGE);add.setOnClickListener(v->addEmployee());content.addView(add,new LinearLayout.LayoutParams(-1,dp(50)));for(JSONObject e:employees){TextView t=tv(e.optString("name")+"\n"+e.optString("id")+" • "+e.optString("role")+"\n"+assignedFor(e.optString("name"))+" items",15,Color.WHITE);t.setBackground(bg(CARD,8));content.addView(t,new LinearLayout.LayoutParams(-1,dp(85)));}}
    int assignedFor(String n){int c=0;for(JSONObject o:items)if(n.equals(o.optString("employee")))c++;return c;}
    void addEmployee(){LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);p.setPadding(dp(10),0,dp(10),0);EditText n=field(p,"Employee name *"),id=field(p,"Employee number"),r=field(p,"Position / role");new AlertDialog.Builder(this).setTitle("Add Employee").setView(p).setPositiveButton("Save",(d,w)->{if(n.getText().toString().trim().isEmpty())return;try{JSONObject e=new JSONObject();e.put("name",n.getText().toString());e.put("id",id.getText().toString());e.put("role",r.getText().toString());employees.add(e);save();employeesScreen();}catch(Exception ignored){}}).setNegativeButton("Cancel",null).show();}
    void reports(){new AlertDialog.Builder(this).setTitle("Reports").setItems(new String[]{"Individual Item Report","Employee Tool List Report","Complete Tool Inventory Report"},(d,w)->toast("PDF report module is next phase")).setNegativeButton("Close",null).show();}
    void settings(){new AlertDialog.Builder(this).setTitle("Settings").setMessage("I.D.T. STEELWORKS AND ENGINEERING\n\nOffline inventory storage is enabled.\n\nVersion 1.0 — Phase 1").setPositiveButton("OK",null).show();}
    void header(String s,final Runnable back){LinearLayout h=new LinearLayout(this);h.setGravity(Gravity.CENTER_VERTICAL);TextView b=tv(s,19,GREEN);b.setTypeface(null,1);b.setOnClickListener(v->back.run());h.addView(b);content.addView(h,new LinearLayout.LayoutParams(-1,dp(55)));}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
