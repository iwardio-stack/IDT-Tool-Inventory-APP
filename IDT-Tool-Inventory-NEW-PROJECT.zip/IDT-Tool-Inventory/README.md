# IDT Tool Inventory

I.D.T. Steelworks & Engineering — offline-first Android tool inventory app.

Phase 1 includes the industrial dashboard, local item/employee storage, add item, add employee, search/lookup, assignment status, categories and report summary screen. Later phases add camera/gallery photos, signatures, issue/return history and A4 PDF reports/sharing.

Build with GitHub Actions using Gradle 8.9 and JDK 17.
