plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.idt.toolinventory"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.idt.toolinventory"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
        debug {
            isMinifyEnabled = false
        }
    }
}

kotlin {
    jvmToolchain(17)
}
