package com.idt.toolinventory

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import androidx.core.content.FileProvider
import android.provider.MediaStore
import android.view.*
import android.widget.*
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.max

private const val GREEN = 0xFF39FF14.toInt()
private const val ORANGE = 0xFFFF7A00.toInt()
private const val BLUE = 0xFF2196F3.toInt()
private const val RED = 0xFFFF3B30.toInt()
private const val BG = 0xFF080808.toInt()
private const val PANEL = 0xFF111518.toInt()
private const val TEXT = 0xFFF2F2F2.toInt()
private const val MUTED = 0xFFB7B7B7.toInt()

data class Tool(
    var number: String,
    var make: String,
    var model: String,
    var type: String,
    var description: String,
    var serial: String,
    var value: Double,
    var assignedTo: String = "Unassigned",
    var photo: String = "",
    var condition: String = "Good",
    var status: String = "Available",
    var notes: String = ""
)

data class Employee(
    var name: String,
    var employeeNo: String,
    var position: String,
    var phone: String = "",
    var email: String = "",
    var photo: String = ""
)

class MainActivity : Activity() {
    private lateinit var store: Store
    private lateinit var root: FrameLayout
    private var page = "home"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        store = Store(this)
        showHome()
    }

    private fun base(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setBackgroundColor(BG)
        return l
    }

    private fun scroll(): ScrollView = ScrollView(this).apply {
        setBackgroundColor(BG)
        isFillViewport = true
    }

    private fun text(s: String, size: Float = 14f, color: Int = TEXT, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(color)
            setPadding(12, 8, 12, 8)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun title(s: String): TextView =
        text(s, 21f, GREEN, true).apply { setPadding(12, 12, 12, 10) }

    private fun input(hint: String, value: String = ""): EditText =
        EditText(this).apply {
            this.hint = hint; setText(value); setTextColor(TEXT); setHintTextColor(MUTED)
            setSingleLine(false); setPadding(14, 10, 14, 10)
            background = GradientDrawable().apply {
                setColor(PANEL); setStroke(1, 0xFF3C4448.toInt()); cornerRadius = 8f
            }
            layoutParams = LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                setMargins(8, 4, 8, 6)
            }
        }

    private fun button(label: String, color: Int = GREEN, action: () -> Unit): Button =
        Button(this).apply {
            text = label; textSize = 14f; setTextColor(if (color == GREEN) Color.BLACK else Color.WHITE)
            background = GradientDrawable().apply { setColor(color); cornerRadius = 10f }
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(-1, 52).apply { setMargins(8, 6, 8, 6) }
        }

    private fun header(titleText: String, back: Boolean = true): LinearLayout {
        val h = LinearLayout(this)
        h.orientation = LinearLayout.HORIZONTAL
        h.gravity = Gravity.CENTER_VERTICAL
        h.setBackgroundColor(Color.BLACK)
        if (back) h.addView(Button(this).apply {
            text = "‹"; textSize = 30f; setTextColor(GREEN); setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { showHome() }
        }, LinearLayout.LayoutParams(60, 60))
        val tv = text(titleText, 19f, GREEN, true)
        h.addView(tv, LinearLayout.LayoutParams(0, 60, 1f))
        return h
    }

    private fun logoHeader(parent: LinearLayout) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.VERTICAL
        row.gravity = Gravity.CENTER
        val iv = ImageView(this).apply {
            setImageResource(com.idt.toolinventory.R.drawable.idt_logo)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }
        row.addView(iv, LinearLayout.LayoutParams(-1, 125))
        parent.addView(row)
    }

    private fun showHome() {
        page = "home"
        val l = base()
        logoHeader(l)

        val stats = LinearLayout(this)
        stats.orientation = LinearLayout.VERTICAL
        val total = store.tools.size
        val value = store.tools.sumOf { it.value }
        val assigned = store.tools.count { it.assignedTo != "Unassigned" }
        val unassigned = total - assigned
        val grid = GridLayout(this).apply { columnCount = 2 }
        statCard(grid, "🔧 Total Items", total.toString(), GREEN)
        statCard(grid, "💰 Total Estimated Value", "R %.2f".format(value), GREEN)
        statCard(grid, "👤 Assigned", assigned.toString(), GREEN)
        statCard(grid, "👤 Unassigned", unassigned.toString(), ORANGE)
        stats.addView(grid)
        l.addView(stats)

        l.addView(text("Items by Type", 17f, GREEN, true))
        val types = store.tools.groupBy { it.type }
        if (types.isEmpty()) {
            l.addView(text("No inventory items yet.", 14f, MUTED))
        } else {
            types.forEach { (type, list) ->
                l.addView(text("$type   ${list.size}   R %.2f".format(list.sumOf { it.value }), 14f))
            }
        }

        l.addView(button("＋  New Item", GREEN) { showNewItem() })
        l.addView(button("⌕  Look Up Item", GREEN) { showLookup() })
        l.addView(button("👥  Employees", ORANGE) { showEmployees() })
        l.addView(button("▤  Reports", ORANGE) { showReports() })
        l.addView(button("⚙  Settings", ORANGE) { showSettings() })
        l.addView(text("DESIGN  |  FABRICATION  |  WELDING  |  INSTALLATION\n\nAny size job welcome, big or small we do them all.", 14f, ORANGE, true).apply {
            gravity = Gravity.CENTER; setPadding(12, 22, 12, 30)
        })

        root = FrameLayout(this)
        root.addView(l)
        setContentView(root)
    }

    private fun statCard(g: GridLayout, a: String, b: String, c: Int) {
        val v = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { setColor(PANEL); setStroke(2, c); cornerRadius = 12f }
            setPadding(5, 10, 5, 10)
        }
        v.addView(text(a, 13f, c, true).apply { gravity = Gravity.CENTER })
        v.addView(text(b, 20f, if (c == ORANGE) ORANGE else GREEN, true).apply { gravity = Gravity.CENTER })
        val p = GridLayout.LayoutParams().apply { width = 0; height = 92; columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(6,6,6,6) }
        g.addView(v, p)
    }

    private fun showNewItem(existing: Tool? = null) {
        val l = base()
        l.addView(header(if (existing == null) "New Item" else "Edit Item"))
        val sc = scroll(); val form = base()
        fun field(label: String, value: String = ""): EditText { form.addView(text(label, 13f, GREEN, true)); val e=input(label,value); form.addView(e); return e }
        val number=field("Item Number *", existing?.number ?: "IDT-%03d".format(store.tools.size+1))
        val make=field("Make *", existing?.make ?: "")
        val model=field("Model Number", existing?.model ?: "")
        val type=field("Type *", existing?.type ?: "")
        val desc=field("Description *", existing?.description ?: "")
        val serial=field("Serial Number", existing?.serial ?: "")
        val value=field("Price Estimate (R)", if (existing == null) "" else existing.value.toString())
        val condition=field("Condition", existing?.condition ?: "Good")
        val status=field("Status", existing?.status ?: "Available")
        sc.addView(form)
        l.addView(sc, LinearLayout.LayoutParams(-1,0,1f))
        l.addView(button("Next", ORANGE) {
            val t=Tool(number.text.toString(),make.text.toString(),model.text.toString(),type.text.toString(),
                desc.text.toString(),serial.text.toString(),value.text.toString().toDoubleOrNull() ?: 0.0,
                existing?.assignedTo ?: "Unassigned", existing?.photo ?: "",condition.text.toString(),status.text.toString())
            showAssign(t, existing)
        })
        setContentView(l)
    }

    private fun showAssign(tool: Tool, existing: Tool?) {
        val l=base(); l.addView(header("Assign to Employee & Photos"))
        val sc=scroll(); val f=base()
        f.addView(text("Assign to Employee",15f,GREEN,true))
        val spinner=Spinner(this)
        val names=mutableListOf("Unassigned")+store.employees.map{it.name}
        spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,names)
        val current=names.indexOf(tool.assignedTo); if(current>=0) spinner.setSelection(current)
        f.addView(spinner)
        f.addView(text("Employee ID Photo",15f,GREEN,true))
        f.addView(button("📷  Take / Choose Employee Photo",BLUE) { choosePhoto(false) })
        f.addView(text("Tool Photo",15f,GREEN,true))
        f.addView(button("📷  Take / Choose Tool Photo",BLUE) { choosePhoto(true) })
        f.addView(text("Current tool: ${tool.make} ${tool.model}\n${tool.number}",14f,TEXT))
        sc.addView(f); l.addView(sc,LinearLayout.LayoutParams(-1,0,1f))
        l.addView(button("Next — Signatures",GREEN) {
            tool.assignedTo=spinner.selectedItem.toString()
            showSignatures(tool, existing)
        })
        setContentView(l)
    }

    private fun choosePhoto(toolPhoto: Boolean) {
        val intent=Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type="image/*"; addCategory(Intent.CATEGORY_OPENABLE) }
        startActivityForResult(intent, if(toolPhoto) 2002 else 2001)
    }

    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(resultCode==RESULT_OK && data?.data!=null) {
            Toast.makeText(this,"Photo selected. It will be attached to the next saved item.",Toast.LENGTH_SHORT).show()
        }
    }

    private fun showSignatures(tool:Tool, existing:Tool?) {
        val l=base(); l.addView(header("Signatures"))
        val sc=scroll(); val f=base()
        f.addView(text("Employee Signature",15f,GREEN,true))
        val employeeSig=SignatureView(this); f.addView(employeeSig,LinearLayout.LayoutParams(-1,180))
        f.addView(button("Clear Employee Signature",ORANGE){employeeSig.clear()})
        f.addView(text("Supervisor Signature",15f,GREEN,true))
        val supervisorSig=SignatureView(this); f.addView(supervisorSig,LinearLayout.LayoutParams(-1,180))
        f.addView(button("Clear Supervisor Signature",ORANGE){supervisorSig.clear()})
        f.addView(text("Notes",15f,GREEN,true))
        val notes=input("Good condition. Assigned for site use.",tool.notes); f.addView(notes)
        sc.addView(f); l.addView(sc,LinearLayout.LayoutParams(-1,0,1f))
        l.addView(button("Save Item",GREEN) {
            tool.notes=notes.text.toString()
            if(existing==null) store.tools.add(tool) else {
                val i=store.tools.indexOfFirst{it.number==existing.number}
                if(i>=0) store.tools[i]=tool else store.tools.add(tool)
            }
            store.save()
            showItemDetails(tool)
        })
        setContentView(l)
    }

    private fun showLookup() {
        val l=base(); l.addView(header("Look Up Item"))
        val search=input("Search item number, make, model, serial...")
        l.addView(search)
        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val sc=scroll(); sc.addView(list); l.addView(sc,LinearLayout.LayoutParams(-1,0,1f))
        fun refresh() {
            list.removeAllViews()
            val q=search.text.toString().lowercase()
            store.tools.filter{q.isBlank() || "${it.number} ${it.make} ${it.model} ${it.serial}".lowercase().contains(q)}
                .forEach{ t ->
                    l.addToolRow(list,t)
                }
        }
        search.setOnEditorActionListener{_,_,_->refresh();true}; refresh()
        setContentView(l)
    }

    private fun LinearLayout.addToolRow(parent:LinearLayout,t:Tool) {
        val b=button("${t.number}   ${t.make} ${t.model}\nS/N: ${t.serial}\n${t.status} • ${t.assignedTo}",GREEN){showItemDetails(t)}
        parent.addView(b)
    }

    private fun showItemDetails(t:Tool) {
        val l=base(); l.addView(header("Item Details"))
        val sc=scroll(); val f=base()
        f.addView(text("${t.number}\n${t.make} ${t.model}\nType: ${t.type}\nDescription: ${t.description}\nSerial: ${t.serial}\nEstimated Value: R %.2f\nCondition: ${t.condition}\nStatus: ${t.status}\nAssigned To: ${t.assignedTo}\nNotes: ${t.notes}",15f))
        f.addView(button("Assign to Employee",GREEN){showAssign(t,t)})
        f.addView(button("Generate PDF",BLUE){sharePdf(PdfMaker.item(this,t,store))})
        f.addView(button("Edit Item",RED){showNewItem(t)})
        sc.addView(f); l.addView(sc,LinearLayout.LayoutParams(-1,0,1f)); setContentView(l)
    }

    private fun showEmployees() {
        val l=base(); l.addView(header("Employees"))
        l.addView(button("+ Add Employee",GREEN){showEmployeeForm(null)})
        val sc=scroll(); val list=base()
        store.employees.forEach{e->
            val count=store.tools.count{it.assignedTo==e.name}
            list.addView(button("${e.name}\n${e.employeeNo} • ${e.position}\n$count Items",GREEN){showEmployeeDetails(e)})
        }
        sc.addView(list); l.addView(sc,LinearLayout.LayoutParams(-1,0,1f)); setContentView(l)
    }

    private fun showEmployeeForm(existing:Employee?) {
        val l=base(); l.addView(header(if(existing==null)"Add New Employee" else "Edit Employee"))
        val sc=scroll(); val f=base()
        fun fld(label:String,value:String=""):EditText{f.addView(text(label,13f,GREEN,true));val e=input(label,value);f.addView(e);return e}
        val name=fld("Full Name",existing?.name?:"")
        val no=fld("Employee Number",existing?.employeeNo?:"")
        val pos=fld("Position",existing?.position?:"Welder / Fabricator")
        val phone=fld("Contact Number",existing?.phone?:"")
        val email=fld("Email",existing?.email?:"")
        sc.addView(f);l.addView(sc,LinearLayout.LayoutParams(-1,0,1f))
        l.addView(button("Save Employee",GREEN){
            val e=Employee(name.text.toString(),no.text.toString(),pos.text.toString(),phone.text.toString(),email.text.toString(),existing?.photo?:"")
            if(existing==null)store.employees.add(e) else {val i=store.employees.indexOfFirst{it.employeeNo==existing.employeeNo};if(i>=0)store.employees[i]=e}
            store.save();showEmployees()
        });setContentView(l)
    }

    private fun showEmployeeDetails(e:Employee) {
        val l=base();l.addView(header("Employee Details"))
        val sc=scroll();val f=base()
        f.addView(text("${e.name}\n${e.employeeNo}\n${e.position}\n${e.phone}\n${e.email}",17f))
        f.addView(text("Assigned Tools",16f,GREEN,true))
        store.tools.filter{it.assignedTo==e.name}.forEach{t->f.addView(text("${t.number} • ${t.make} ${t.model} • R %.2f".format(t.value),14f))}
        f.addView(button("Generate Employee Tool List PDF",BLUE){sharePdf(PdfMaker.employee(this,e,store))})
        f.addView(button("Edit Employee",ORANGE){showEmployeeForm(e)})
        sc.addView(f);l.addView(sc,LinearLayout.LayoutParams(-1,0,1f));setContentView(l)
    }

    private fun showReports() {
        val l=base();l.addView(header("Reports"));val sc=scroll();val f=base()
        f.addView(button("📄 Complete Inventory Report",GREEN){sharePdf(PdfMaker.all(this,store))})
        f.addView(button("📄 Employee Tool List Reports",ORANGE){ if(store.employees.isNotEmpty()) sharePdf(PdfMaker.employee(this,store.employees.first(),store)) else Toast.makeText(this,"Add an employee first.",Toast.LENGTH_SHORT).show() })
        f.addView(button("📄 Individual Item Report",BLUE){ if(store.tools.isNotEmpty()) sharePdf(PdfMaker.item(this,store.tools.first(),store)) else Toast.makeText(this,"Add an item first.",Toast.LENGTH_SHORT).show() })
        sc.addView(f);l.addView(sc,LinearLayout.LayoutParams(-1,0,1f));setContentView(l)
    }

    private fun showSettings() {
        val l=base();l.addView(header("Settings"));val sc=scroll();val f=base()
        f.addView(text("I.D.T. STEELWORKS AND ENGINEERING\nWelding • Fabrication • Installation\nWestern Cape\niwardio@idtsteelwork.co.za",17f))
        f.addView(button("Clear all local inventory",RED){
            AlertDialog.Builder(this).setTitle("Clear inventory?").setMessage("This removes local demo data and saved records.")
                .setNegativeButton("Cancel",null).setPositiveButton("Clear"){_,_->store.tools.clear();store.employees.clear();store.save();showHome()}.show()
        })
        sc.addView(f);l.addView(sc,LinearLayout.LayoutParams(-1,0,1f));setContentView(l)
    }

    private fun sharePdf(file:File) {
        val uri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", file)
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(i, "Share IDT PDF"))
    }
}

class SignatureView(ctx:Context):View(ctx){
    private val path=Path()
    private val paint=Paint().apply{color=Color.BLACK;style=Paint.Style.STROKE;strokeWidth=5f;strokeCap=Paint.Cap.ROUND;isAntiAlias=true}
    init{setBackgroundColor(Color.WHITE)}
    override fun onDraw(c:Canvas){super.onDraw(c);c.drawPath(path,paint)}
    override fun onTouchEvent(e:android.view.MotionEvent):Boolean{
        when(e.action){MotionEvent.ACTION_DOWN->path.moveTo(e.x,e.y);MotionEvent.ACTION_MOVE->path.lineTo(e.x,e.y)}
        invalidate();return true
    }
    fun clear(){path.reset();invalidate()}
}

class Store(private val ctx:Context){
    val tools=mutableListOf<Tool>()
    val employees=mutableListOf<Employee>()
    private val p=ctx.getSharedPreferences("idt_inventory",Context.MODE_PRIVATE)
    init{
        if(!p.getBoolean("seeded",false)){
            tools.add(Tool("IDT-001","Makita","DHR243Z","Rotary Hammer","18V Cordless Rotary Hammer Drill with 3 modes","A1234567",3699.0))
            tools.add(Tool("IDT-002","DeWalt","DWE7492","Table Saw","Heavy duty table saw","B7654321",8500.0,"Mark Daniels"))
            tools.add(Tool("IDT-003","Bosch","GWS 2200","Angle Grinder","Professional angle grinder","C9876543",2450.0,"Pieter Jacobs"))
            tools.add(Tool("IDT-004","Lincoln","PowerMIG 220","Welding Machine","Portable welding machine","L1122334",9500.0,"Iwardio Du Toit"))
            tools.add(Tool("IDT-005","Makita","DTD152","Impact Driver","18V impact driver","M2233445",2150.0,"Johan Smith"))
            employees.add(Employee("Iwardio Du Toit","IDT-001","Manager"))
            employees.add(Employee("Johan Smith","IDT-003","Welder / Fabricator"))
            employees.add(Employee("Pieter Jacobs","IDT-004","Installer"))
            employees.add(Employee("Mark Daniels","IDT-005","General Worker"))
            p.edit().putBoolean("seeded",true).apply()
        }
    }
    fun save(){
        // Compact local persistence using JSON-like line storage.
        val t=tools.joinToString("\n"){listOf(it.number,it.make,it.model,it.type,it.description,it.serial,it.value,it.assignedTo,it.condition,it.status,it.notes).joinToString("|")}
        val e=employees.joinToString("\n"){listOf(it.name,it.employeeNo,it.position,it.phone,it.email).joinToString("|")}
        p.edit().putString("tools",t).putString("employees",e).apply()
    }
}

object PdfMaker {
    private const val W=595
    private const val H=842
    private fun header(c:Canvas,p:Paint,title:String){
        p.color=Color.BLACK;c.drawRect(0f,0f,W.toFloat(),55f,p)
        p.color=GREEN;p.textSize=20f;p.typeface=Typeface.DEFAULT_BOLD
        c.drawText("I.D.T. STEELWORKS AND ENGINEERING",22f,28f,p)
        p.color=Color.WHITE;p.textSize=10f;p.typeface=Typeface.DEFAULT
        c.drawText("Welding | Fabrication | Installation",22f,45f,p)
        p.color=ORANGE;p.textSize=15f;p.typeface=Typeface.DEFAULT_BOLD;c.drawText(title,22f,80f,p)
    }
    private fun baseDoc():android.graphics.pdf.PdfDocument=android.graphics.pdf.PdfDocument()
    fun item(ctx:Context,t:Tool,s:Store):File{
        val d=baseDoc();val page=d.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(W,H,1).create());val c=page.canvas;val p=Paint(Paint.ANTI_ALIAS_FLAG)
        header(c,p,"TOOL INVENTORY REPORT - INDIVIDUAL ITEM")
        p.color=Color.BLACK;p.textSize=13f
        val lines=listOf("Item Number: ${t.number}","Make: ${t.make}","Model Number: ${t.model}","Type: ${t.type}","Description: ${t.description}","Serial Number: ${t.serial}","Estimated Value: R %.2f".format(t.value),"Assigned To: ${t.assignedTo}","Condition: ${t.condition}","Status: ${t.status}","Notes: ${t.notes}")
        var y=115f;for(x in lines){c.drawText(x.take(75),25f,y,p);y+=28}
        p.color=Color.DKGRAY;p.textSize=11f;c.drawText("Employee Signature",40f,730f,p);c.drawText("Supervisor Signature",350f,730f,p)
        c.drawLine(25f,750f,270f,750f,p);c.drawLine(325f,750f,570f,750f,p)
        d.finishPage(page);return write(ctx,d,"IDT-Individual-${t.number}.pdf")
    }
    fun employee(ctx:Context,e:Employee,s:Store):File{
        val d=baseDoc();val page=d.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(W,H,1).create());val c=page.canvas;val p=Paint(Paint.ANTI_ALIAS_FLAG)
        header(c,p,"EMPLOYEE TOOL ASSIGNMENT REPORT")
        p.color=Color.BLACK;p.textSize=13f;c.drawText("${e.name}  •  ${e.employeeNo}  •  ${e.position}",25f,110f,p)
        var y=145f; s.tools.filter{it.assignedTo==e.name}.forEachIndexed{i,t->c.drawText("${i+1}. ${t.number}  ${t.make} ${t.model}  S/N ${t.serial}  R %.2f".format(t.value),25f,y,p);y+=28}
        c.drawText("Employee Signature",35f,730f,p);c.drawText("Supervisor Signature",350f,730f,p);c.drawLine(25f,750f,270f,750f,p);c.drawLine(325f,750f,570f,750f,p)
        d.finishPage(page);return write(ctx,d,"IDT-Employee-${e.employeeNo}.pdf")
    }
    fun all(ctx:Context,s:Store):File{
        val d=baseDoc();val page=d.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(W,H,1).create());val c=page.canvas;val p=Paint(Paint.ANTI_ALIAS_FLAG)
        header(c,p,"COMPLETE TOOL INVENTORY REPORT")
        p.color=Color.BLACK;p.textSize=10f
        var y=110f;c.drawText("#   Item     Make       Model       Type             Serial       Assigned        Value",18f,y,p);y+=22
        s.tools.take(20).forEachIndexed{i,t->{c.drawText("${i+1}   ${t.number}  ${t.make.take(9)}  ${t.model.take(10)}  ${t.type.take(14)}  ${t.serial.take(10)}  ${t.assignedTo.take(12)}  R%.2f".format(t.value),18f,y,p);y+=26}}
        p.typeface=Typeface.DEFAULT_BOLD;p.textSize=14f;c.drawText("TOTAL ESTIMATED VALUE: R %.2f".format(s.tools.sumOf{it.value}),350f,790f,p)
        d.finishPage(page);return write(ctx,d,"IDT-Complete-Inventory.pdf")
    }
    private fun write(ctx:Context,d:android.graphics.pdf.PdfDocument,name:String):File{
        val dir=File(ctx.cacheDir,"reports");dir.mkdirs();val f=File(dir,name);FileOutputStream(f).use{d.writeTo(it)};d.close();return f
    }
}
