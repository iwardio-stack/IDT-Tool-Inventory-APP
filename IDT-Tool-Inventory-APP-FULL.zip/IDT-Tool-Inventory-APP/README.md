# I.D.T. Tool Inventory App

Native Android inventory app based on the supplied master specification.

## Main functions
- Dashboard with Total Items, Estimated Value, Assigned and Unassigned
- Item register
- Item lookup/search
- Employee register
- Assign tools to employees
- Tool and employee photos
- Employee and supervisor signatures
- Notes and condition/status
- Individual item PDF report
- Employee tool-list PDF report
- Complete inventory PDF report
- Android share sheet for generated PDFs
- Offline local storage

## Build
GitHub Actions is configured in `.github/workflows/build.yml`.

The workflow uses JDK 17 and Gradle 8.9 and builds:
`app/build/outputs/apk/debug/app-debug.apk`
