package com.idt.toolinventory;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
    static final int GREEN=Color.rgb(124,255,0), ORANGE=Color.rgb(255,101,0), BLACK=Color.rgb(8,8,8),
            DARK=Color.rgb(17,17,17), WHITE=Color.WHITE, GREY=Color.rgb(190,190,190);
    LinearLayout root, content;
    ArrayList<Item> items=new ArrayList<>(); ArrayList<Employee> employees=new ArrayList<>();
    SharedPreferences prefs;
    int green=GREEN;
    EditText itemNo, make, model, type, desc, serial, value;
    EditText empName, empNo, empRole;
    String currentToolPhoto="", currentEmpPhoto="", assignedEmployee="";
    Bitmap clientSig, supervisorSig;
    SignatureView sigEmployee, sigSupervisor;
    Item editingItem;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        prefs=getSharedPreferences("idt_inventory",MODE_PRIVATE);
        loadData();
        seedEmployeesIfEmpty();
        showHome();
    }

    TextView tv(String text,int sp,int color){
        TextView t=new TextView(this); t.setText(text); t.setTextSize(sp); t.setTextColor(color);
        t.setPadding(12,10,12,10); return t;
    }
    Button btn(String text,int color){
        Button b=new Button(this); b.setText(text); b.setTextColor(color); b.setTextSize(15);
        b.setAllCaps(false); b.setBackground(round(DARK,2,Color.DKGRAY)); b.setPadding(12,8,12,8);
        return b;
    }
    GradientDrawable round(int fill,int stroke,int strokeColor){
        GradientDrawable g=new GradientDrawable(); g.setColor(fill); g.setCornerRadius(14); g.setStroke(stroke,strokeColor); return g;
    }
    EditText field(String hint){
        EditText e=new EditText(this); e.setHint(hint); e.setTextColor(WHITE); e.setHintTextColor(Color.GRAY);
        e.setTextSize(15); e.setSingleLine(false); e.setPadding(14,8,14,8); e.setBackground(round(Color.rgb(23,27,29),1,Color.rgb(55,55,55)));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,52); p.setMargins(0,5,0,5); e.setLayoutParams(p); return e;
    }
    void base(String title){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BLACK);
        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(8,8,8,8);
        TextView back=tv("‹",38,GREEN); back.setGravity(Gravity.CENTER); back.setOnClickListener(v->showHome());
        bar.addView(back,new LinearLayout.LayoutParams(48,58));
        TextView h=tv(title,20,GREEN); h.setTypeface(null,1); bar.addView(h,new LinearLayout.LayoutParams(0,58,1));
        TextView logo=tv("I.D.T.",20,GREEN); logo.setTypeface(null,1); bar.addView(logo);
        root.addView(bar);
        ScrollView sv=new ScrollView(this); content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(12,5,12,20); sv.addView(content);
        root.addView(sv,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }
    void section(String s){ TextView t=tv(s.toUpperCase(),14,WHITE); t.setTypeface(null,1); t.setBackgroundColor(Color.BLACK); content.addView(t,new LinearLayout.LayoutParams(-1,38)); }
    void add(View v){content.addView(v);}
    void spacer(int h){ Space s=new Space(this); add(s); s.getLayoutParams().height=h; s.requestLayout();}

    void showHome(){
        base("IDT TOOL INVENTORY");
        TextView brand=tv("I.D.T. STEELWORKS AND ENGINEERING\nWELDING • FABRICATION • INSTALLATION",21,GREEN);
        brand.setGravity(Gravity.CENTER); brand.setTypeface(null,1); add(brand);
        TextView stats=tv("TOTAL ITEMS     "+items.size()+"        ASSIGNED     "+countAssigned()+"\nESTIMATED VALUE     R "+money(totalValue()),17,WHITE);
        stats.setGravity(Gravity.CENTER); stats.setPadding(5,22,5,22); add(stats);
        section("Inventory");
        addMenu("＋  New Item",GREEN,v->newItem());
        addMenu("⌕  Look Up Item",GREEN,v->lookup());
        addMenu("♟  Employees",ORANGE,v->employeeList());
        addMenu("▣  Reports",ORANGE,v->reports());
        addMenu("⚙  Settings",GREY,v->settings());
    }
    void addMenu(String s,int color,View.OnClickListener l){ Button b=btn(s,color); b.setTextSize(17); b.setGravity(Gravity.CENTER_LEFT); b.setOnClickListener(l); b.setBackground(round(Color.rgb(12,12,12),2,color)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,52);p.setMargins(0,5,0,5);add(b); }

    int countAssigned(){int n=0;for(Item i:items)if(i.assigned!=null&&!i.assigned.isEmpty())n++;return n;}
    double totalValue(){double x=0;for(Item i:items)x+=i.value;return x;}
    String money(double v){return String.format(Locale.US,"%,.2f",v);}

    void newItem(){
        base(editingItem==null?"NEW ITEM":"EDIT ITEM");
        itemNo=field("Item Number *"); make=field("Make *"); model=field("Model Number"); type=field("Type *");
        desc=field("Description *"); serial=field("Serial Number"); value=field("Price Estimate (R)");
        add(itemNo);add(make);add(model);add(type);add(desc);add(serial);add(value);
        if(editingItem!=null){itemNo.setText(editingItem.no);make.setText(editingItem.make);model.setText(editingItem.model);type.setText(editingItem.type);desc.setText(editingItem.desc);serial.setText(editingItem.serial);value.setText(""+editingItem.value);}
        Button next=btn("Next  →",ORANGE); next.setBackground(round(ORANGE,1,ORANGE)); next.setOnClickListener(v->assignmentScreen());add(next);
    }
    void assignmentScreen(){
        if(itemNo.getText().toString().trim().isEmpty()||make.getText().toString().trim().isEmpty()){toast("Item Number and Make are required");return;}
        base("ASSIGN TO EMPLOYEE & PHOTOS");
        section("Assign to Employee");
        Spinner sp=new Spinner(this); ArrayList<String> names=new ArrayList<>(); names.add("Unassigned"); for(Employee e:employees)names.add(e.name);
        ArrayAdapter<String>a=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,names); sp.setAdapter(a);
        if(assignedEmployee!=null&&!assignedEmployee.isEmpty()) for(int x=0;x<names.size();x++)if(names.get(x).equals(assignedEmployee))sp.setSelection(x);
        sp.setBackgroundColor(Color.WHITE); add(sp);
        TextView empPhoto=tv("Employee ID Photo",16,GREEN); add(empPhoto);
        ImageView iv=new ImageView(this);iv.setImageBitmap(loadBitmap(currentEmpPhoto));iv.setBackgroundColor(Color.DKGRAY);iv.setScaleType(ImageView.ScaleType.CENTER_CROP);add(iv);iv.getLayoutParams().height=150;
        addPhotoButtons(v->choosePhoto(false,iv),v->takePhoto(false,iv));
        TextView tool=tv("Tool Photo",16,GREEN);add(tool);
        ImageView toolIv=new ImageView(this);toolIv.setImageBitmap(loadBitmap(currentToolPhoto));toolIv.setBackgroundColor(Color.DKGRAY);toolIv.setScaleType(ImageView.ScaleType.CENTER_CROP);add(toolIv);toolIv.getLayoutParams().height=210;
        addPhotoButtons(v->choosePhoto(true,toolIv),v->takePhoto(true,toolIv));
        Button next=btn("Next  →",ORANGE);next.setOnClickListener(v->{assignedEmployee=sp.getSelectedItem().toString();signatureScreen();});add(next);
    }
    void addPhotoButtons(View.OnClickListener choose,View.OnClickListener take){
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);
        Button a=btn("📷 Take Photo",WHITE);Button b=btn("▣ Choose Photo",WHITE);a.setOnClickListener(take);b.setOnClickListener(choose);
        row.addView(a,new LinearLayout.LayoutParams(0,55,1));row.addView(b,new LinearLayout.LayoutParams(0,55,1));add(row);
    }
    void choosePhoto(boolean tool,ImageView iv){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,tool?21:20);}
    void takePhoto(boolean tool,ImageView iv){Intent i=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);startActivityForResult(i,tool?31:30);}
    @Override protected void onActivityResult(int r,int c,Intent d){
        super.onActivityResult(r,c,d); if(c!=RESULT_OK)return;
        try{
            Bitmap b=null;
            if(d!=null&&d.getData()!=null)b=MediaStore.Images.Media.getBitmap(getContentResolver(),d.getData());
            else if(d!=null&&d.getExtras()!=null)b=(Bitmap)d.getExtras().get("data");
            if(b==null)return;
            boolean tool=(r==21||r==31);String fn=(tool?"tool_":"emp_")+System.currentTimeMillis()+".jpg";File f=new File(getFilesDir(),fn);
            FileOutputStream o=new FileOutputStream(f);b.compress(Bitmap.CompressFormat.JPEG,85,o);o.close();
            if(tool)currentToolPhoto=f.getAbsolutePath();else currentEmpPhoto=f.getAbsolutePath();
            toast("Photo saved");
        }catch(Exception e){toast("Photo error: "+e.getMessage());}
    }

    void signatureScreen(){
        base("SIGNATURES & SAVE");
        section("Employee Signature");sigEmployee=new SignatureView(this);add(sigEmployee);sigEmployee.getLayoutParams().height=150;
        Button ce=btn("Clear Employee Signature",WHITE);ce.setOnClickListener(v->sigEmployee.clear());add(ce);
        section("Supervisor Signature");sigSupervisor=new SignatureView(this);add(sigSupervisor);sigSupervisor.getLayoutParams().height=150;
        Button cs=btn("Clear Supervisor Signature",WHITE);cs.setOnClickListener(v->sigSupervisor.clear());add(cs);
        add(field("Notes"));
        Button save=btn("SAVE ITEM",GREEN);save.setBackground(round(GREEN,1,GREEN));save.setTextColor(Color.BLACK);save.setOnClickListener(v->saveItem());add(save);
    }
    void saveItem(){
        try{
            Item i=editingItem==null?new Item():editingItem;i.no=itemNo.getText().toString();i.make=make.getText().toString();i.model=model.getText().toString();i.type=type.getText().toString();
            i.desc=desc.getText().toString();i.serial=serial.getText().toString();i.value=Double.parseDouble(value.getText().toString().replace(",","").trim().isEmpty()?"0":value.getText().toString().replace(",",""));i.assigned=assignedEmployee;i.toolPhoto=currentToolPhoto;i.empPhoto=currentEmpPhoto;
            if(editingItem==null)items.add(i);saveData();editingItem=null;toast("Item saved");showHome();
        }catch(Exception e){toast("Please check the price field");}
    }

    void lookup(){
        base("LOOK UP ITEM");
        EditText q=field("Search item number, make, model, serial");add(q);
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);add(list);
        Runnable render=()->{list.removeAllViews();String s=q.getText().toString().toLowerCase(Locale.US);for(Item i:items)if(s.isEmpty()||(i.no+" "+i.make+" "+i.model+" "+i.serial).toLowerCase().contains(s))addItemRow(list,i);};
        q.setOnKeyListener((v,k,e)->{render.run();return false;});render.run();
    }
    void addItemRow(LinearLayout list,Item i){
        Button b=btn(i.no+"   "+i.make+" "+i.model+"\n"+i.type+"  •  S/N: "+i.serial+"\n"+(i.assigned.isEmpty()?"Unassigned":i.assigned)+"   R "+money(i.value),GREEN);
        b.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);b.setOnClickListener(v->itemDetails(i));list.addView(b,new LinearLayout.LayoutParams(-1,105));
    }
    void itemDetails(Item i){
        editingItem=i;newItem();
    }

    void employeeList(){
        base("EMPLOYEES");
        Button add=btn("+ Add Employee",GREEN);add.setOnClickListener(v->addEmployee());add(add);
        for(Employee e:employees){Button b=btn(e.name+"\n"+e.no+"  •  "+e.role+"\n"+employeeItems(e.no)+" items");b.setGravity(Gravity.LEFT);b.setOnClickListener(v->employeeDetails(e));add(b);}
    }
    int employeeItems(String name){int n=0;for(Item i:items)if(name.equals(i.assigned))n++;return n;}
    void addEmployee(){
        base("NEW EMPLOYEE");empName=field("Employee Name *");empNo=field("Employee ID");empRole=field("Role");
        add(empName);add(empNo);add(empRole);Button b=btn("SAVE EMPLOYEE",GREEN);b.setOnClickListener(v->{if(empName.getText().toString().trim().isEmpty()){toast("Name required");return;}employees.add(new Employee(empName.getText().toString(),empNo.getText().toString(),empRole.getText().toString()));saveData();employeeList();});add(b);
    }
    void employeeDetails(Employee e){base("EMPLOYEE");add(tv(e.name,24,GREEN));add(tv(e.no+"\n"+e.role+"\n\nAssigned Items: "+employeeItems(e.name),17,WHITE));for(Item i:items)if(e.name.equals(i.assigned))addItemRow(content,i);}

    void reports(){
        base("REPORTS");
        section("PDF Reports");
        Button a=btn("Individual Item Report (PDF)",GREEN);a.setOnClickListener(v->chooseItemForReport());add(a);
        Button b=btn("Employee Tool List Report (PDF)",ORANGE);b.setOnClickListener(v->chooseEmployeeForReport());add(b);
        Button c=btn("All Items Report (PDF)",GREEN);c.setOnClickListener(v->sharePdf(PdfReport.allItems(this,items)));add(c);
    }
    void chooseItemForReport(){if(items.isEmpty()){toast("No items yet");return;}base("SELECT ITEM REPORT");for(Item i:items){Button b=btn(i.no+" • "+i.make+" "+i.model);b.setOnClickListener(v->sharePdf(PdfReport.item(this,i)));add(b);}}
    void chooseEmployeeForReport(){if(employees.isEmpty()){toast("No employees");return;}base("SELECT EMPLOYEE REPORT");for(Employee e:employees){Button b=btn(e.name+" • "+e.role);b.setOnClickListener(v->sharePdf(PdfReport.employee(this,e,items)));add(b);}}
    void sharePdf(File f){if(f==null||!f.exists()){toast("Could not create PDF");return;}Intent s=new Intent(Intent.ACTION_SEND);s.setType("application/pdf");s.putExtra(Intent.EXTRA_STREAM,Uri.fromFile(f));s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);try{startActivity(Intent.createChooser(s,"Share report"));}catch(Exception e){toast("No share app available");}}

    void settings(){
        base("SETTINGS");add(tv("I.D.T. STEELWORKS AND ENGINEERING",20,GREEN));add(tv("Welding • Fabrication • Installation\nWestern Cape\n\nData is stored locally on this phone.",16,WHITE));
        Button clear=btn("Delete ALL Inventory Data",ORANGE);clear.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Delete all data?").setMessage("This cannot be undone.").setNegativeButton("Cancel",null).setPositiveButton("Delete", (d,w)->{items.clear();employees.clear();saveData();showHome();}).show());add(clear);
    }
    void seedEmployeesIfEmpty(){if(employees.isEmpty()){employees.add(new Employee("Iwardio Du Toit","IDT-001","Manager"));employees.add(new Employee("Johan Smith","IDT-003","Welder / Fabricator"));employees.add(new Employee("Pieter Jacobs","IDT-004","Installer"));employees.add(new Employee("Mark Daniels","IDT-005","General Worker"));saveData();}}
    void saveData(){
        JSONArray ia=new JSONArray();try{for(Item i:items)ia.put(i.toJson());JSONArray ea=new JSONArray();for(Employee e:employees)ea.put(e.toJson());prefs.edit().putString("items",ia.toString()).putString("employees",ea.toString()).apply();}catch(Exception ignored){}
    }
    void loadData(){
        try{JSONArray a=new JSONArray(prefs.getString("items","[]"));for(int x=0;x<a.length();x++)items.add(Item.fromJson(a.getJSONObject(x)));JSONArray e=new JSONArray(prefs.getString("employees","[]"));for(int x=0;x<e.length();x++)employees.add(Employee.fromJson(e.getJSONObject(x)));}catch(Exception ignored){}
    }
    Bitmap loadBitmap(String p){try{if(p!=null&&!p.isEmpty())return BitmapFactory.decodeFile(p);}catch(Exception ignored){}return null;}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    void add(View v, int h){content.addView(v,new LinearLayout.LayoutParams(-1,h));}

    static class Item{
        String no="",make="",model="",type="",desc="",serial="",assigned="",toolPhoto="",empPhoto="";double value=0;
        JSONObject toJson()throws Exception{return new JSONObject().put("no",no).put("make",make).put("model",model).put("type",type).put("desc",desc).put("serial",serial).put("assigned",assigned).put("toolPhoto",toolPhoto).put("empPhoto",empPhoto).put("value",value);}
        static Item fromJson(JSONObject o)throws Exception{Item i=new Item();i.no=o.optString("no");i.make=o.optString("make");i.model=o.optString("model");i.type=o.optString("type");i.desc=o.optString("desc");i.serial=o.optString("serial");i.assigned=o.optString("assigned");i.toolPhoto=o.optString("toolPhoto");i.empPhoto=o.optString("empPhoto");i.value=o.optDouble("value");return i;}
    }
    static class Employee{
        String name,no,role;Employee(String n,String i,String r){name=n;no=i;role=r;}
        JSONObject toJson()throws Exception{return new JSONObject().put("name",name).put("no",no).put("role",role);}
        static Employee fromJson(JSONObject o)throws Exception{return new Employee(o.optString("name"),o.optString("no"),o.optString("role"));}
    }
}
