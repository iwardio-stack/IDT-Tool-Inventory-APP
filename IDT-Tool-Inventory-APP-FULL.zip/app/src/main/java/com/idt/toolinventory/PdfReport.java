package com.idt.toolinventory;

import android.content.*;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class PdfReport {
    static final int W=595,H=842;
    static Paint p(int size,int color,boolean bold){Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setTextSize(size);p.setColor(color);p.setTypeface(bold?Typeface.DEFAULT_BOLD:Typeface.DEFAULT);return p;}
    static File newFile(Context c,String prefix){return new File(c.getExternalFilesDir(null),prefix+"_"+System.currentTimeMillis()+".pdf");}
    static void header(Canvas c,Paint p){c.drawRect(28,28,567,78,p(1,Color.BLACK,false));c.drawText("I.D.T. STEELWORKS AND ENGINEERING",42,50,p(15,Color.WHITE,true));c.drawText("TOOL INVENTORY REPORT",42,68,p(9,Color.WHITE,false));c.drawText("Welding | Fabrication | Installation",350,50,p(8,Color.WHITE,false));c.drawText("Western Cape",450,65,p(8,Color.WHITE,false));}
    static void footer(Canvas c){c.drawText("I.D.T. STEELWORKS AND ENGINEERING  •  iwardio@idtsteelwork.co.za",35,820,p(7,Color.DKGRAY,false));}
    static void save(PdfDocument d,File f)throws Exception{FileOutputStream o=new FileOutputStream(f);d.writeTo(o);o.close();d.close();}
    static File item(Context c,MainActivity.Item i){
        try{PdfDocument d=new PdfDocument();PdfDocument.Page pg=d.startPage(new PdfDocument.PageInfo.Builder(W,H,1).create());Canvas x=pg.getCanvas();header(x,null);
            x.drawText("INDIVIDUAL TOOL REPORT",35,105,p(13,Color.BLACK,true));
            int y=125;x.drawText("Item Number: "+i.no,35,y,p(10,Color.BLACK,true));x.drawText("Make: "+i.make,35,y+20,p(10,Color.BLACK,false));x.drawText("Model: "+i.model,35,y+40,p(10,Color.BLACK,false));x.drawText("Type: "+i.type,35,y+60,p(10,Color.BLACK,false));x.drawText("Serial Number: "+i.serial,35,y+80,p(10,Color.BLACK,false));x.drawText("Value: R "+String.format(Locale.US,"%,.2f",i.value),35,y+100,p(10,Color.BLACK,false));x.drawText("Assigned To: "+(i.assigned.isEmpty()?"Unassigned":i.assigned),35,y+120,p(10,Color.BLACK,false));x.drawText("Description:",35,y+150,p(10,Color.BLACK,true));x.drawText(i.desc,35,y+168,p(9,Color.DKGRAY,false));
            if(i.toolPhoto!=null&&!i.toolPhoto.isEmpty()){Bitmap b=BitmapFactory.decodeFile(i.toolPhoto);if(b!=null)x.drawBitmap(b,null,new Rect(340,125,560,300),p(1,Color.BLACK,false));}
            x.drawLine(35,330,560,330,p(1,Color.DKGRAY,false));x.drawText("NOTES / COMMENTS",35,350,p(10,Color.BLACK,true));x.drawText("Item recorded in IDT Tool Inventory.",35,370,p(9,Color.DKGRAY,false));footer(x);d.finishPage(pg);File f=newFile(c,"IDT_ITEM_"+i.no);save(d,f);return f;
        }catch(Exception e){return null;}
    }
    static File employee(Context c,MainActivity.Employee e,ArrayList<MainActivity.Item> items){
        try{PdfDocument d=new PdfDocument();PdfDocument.Page pg=d.startPage(new PdfDocument.PageInfo.Builder(W,H,1).create());Canvas x=pg.getCanvas();header(x,null);x.drawText("EMPLOYEE TOOL ASSIGNMENT REPORT",35,105,p(13,Color.BLACK,true));x.drawText(e.name+"   •   "+e.no+"   •   "+e.role,35,125,p(10,Color.BLACK,false));int y=155;
            String[] heads={"#","Item","Make","Model","Type","Serial","Value"};int[] xs={35,52,105,175,250,330,445};for(int z=0;z<heads.length;z++)x.drawText(heads[z],xs[z],y,p(8,Color.BLACK,true));y+=18;int n=1;double total=0;for(MainActivity.Item i:items)if(e.name.equals(i.assigned)){x.drawText(""+n++,35,y,p(7,Color.BLACK,false));x.drawText(i.no,52,y,p(7,Color.BLACK,false));x.drawText(shorten(i.make,9),105,y,p(7,Color.BLACK,false));x.drawText(shorten(i.model,10),175,y,p(7,Color.BLACK,false));x.drawText(shorten(i.type,12),250,y,p(7,Color.BLACK,false));x.drawText(shorten(i.serial,13),330,y,p(7,Color.BLACK,false));x.drawText("R "+String.format(Locale.US,"%.2f",i.value),445,y,p(7,Color.BLACK,false));total+=i.value;y+=22;if(y>750)break;}
            x.drawText("Total Items: "+(n-1),35,y+20,p(10,Color.BLACK,true));x.drawText("Total Estimated Value: R "+String.format(Locale.US,"%,.2f",total),35,y+40,p(10,Color.BLACK,true));footer(x);d.finishPage(pg);File f=newFile(c,"IDT_EMPLOYEE_"+e.name.replace(" ","_"));save(d,f);return f;
        }catch(Exception ex){return null;}
    }
    static File allItems(Context c,ArrayList<MainActivity.Item> items){
        try{PdfDocument d=new PdfDocument();PdfDocument.Page pg=d.startPage(new PdfDocument.PageInfo.Builder(W,H,1).create());Canvas x=pg.getCanvas();header(x,null);x.drawText("COMPLETE TOOL INVENTORY REPORT",35,105,p(13,Color.BLACK,true));int y=130;String[] heads={"#","Item","Make","Model","Type","Serial","Assigned","Value"};int[] xs={30,48,95,150,215,275,350,485};for(int z=0;z<heads.length;z++)x.drawText(heads[z],xs[z],y,p(7,Color.BLACK,true));y+=20;double total=0;int n=1;for(MainActivity.Item i:items){x.drawText(""+n++,30,y,p(7,Color.BLACK,false));x.drawText(i.no,48,y,p(7,Color.BLACK,false));x.drawText(shorten(i.make,8),95,y,p(7,Color.BLACK,false));x.drawText(shorten(i.model,9),150,y,p(7,Color.BLACK,false));x.drawText(shorten(i.type,10),215,y,p(7,Color.BLACK,false));x.drawText(shorten(i.serial,12),275,y,p(7,Color.BLACK,false));x.drawText(shorten(i.assigned,18),350,y,p(7,Color.BLACK,false));x.drawText("R "+String.format(Locale.US,"%.2f",i.value),485,y,p(7,Color.BLACK,false));total+=i.value;y+=18;if(y>770)break;}x.drawText("Total Estimated Value: R "+String.format(Locale.US,"%,.2f",total),350,800,p(10,Color.BLACK,true));footer(x);d.finishPage(pg);File f=newFile(c,"IDT_ALL_ITEMS");save(d,f);return f;
        }catch(Exception ex){return null;}
    }
    static String shorten(String s,int n){if(s==null)return "";return s.length()>n?s.substring(0,n):s;}
}
