package com.idt.toolinventory;

import android.content.Context;
import android.graphics.*;
import android.util.AttributeSet;
import android.view.*;

public class SignatureView extends View {
    private final Path path = new Path();
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Bitmap bitmap;
    public SignatureView(Context c) { super(c); init(); }
    public SignatureView(Context c, AttributeSet a) { super(c,a); init(); }
    private void init() {
        paint.setColor(Color.BLACK);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(4f);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);
        setBackgroundColor(Color.WHITE);
    }
    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        c.drawPath(path, paint);
    }
    @Override public boolean onTouchEvent(android.view.MotionEvent e) {
        float x=e.getX(), y=e.getY();
        switch(e.getAction()) {
            case MotionEvent.ACTION_DOWN: path.moveTo(x,y); invalidate(); return true;
            case MotionEvent.ACTION_MOVE: path.lineTo(x,y); invalidate(); return true;
            case MotionEvent.ACTION_UP: path.lineTo(x,y); invalidate(); return true;
        }
        return true;
    }
    public void clear() { path.reset(); invalidate(); }
    public Bitmap getBitmap() {
        Bitmap b=Bitmap.createBitmap(Math.max(1,getWidth()),Math.max(1,getHeight()),Bitmap.Config.ARGB_8888);
        Canvas c=new Canvas(b); c.drawColor(Color.WHITE); c.drawPath(path,paint); return b;
    }
}
