# IDT Tool Inventory APP

Full replacement Android project for I.D.T. Steelworks and Engineering.

## Build
GitHub Actions builds the debug APK automatically on every push to `main`, or manually from Actions.

## Features
- Inventory dashboard
- Add/edit tools
- Employee assignment
- Tool and employee photos
- Local offline storage
- Employee list
- Item lookup
- Individual item PDF
- Employee tool-list PDF
- Complete inventory PDF
- Android share sheet for PDFs
- Signature capture controls
- I.D.T. black / neon-green / orange branding

No code patching is required. Upload the contents of this ZIP to a clean repository.
